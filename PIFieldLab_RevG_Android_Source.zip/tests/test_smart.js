const assert=require('node:assert/strict');
const M=require('../app/src/main/assets/metal-id-engine.js');
const S=require('../app/src/main/assets/metal-smart-logic.js');
for(let m of Object.keys(M.METALS)){
  let t=S.trainingStart(m,20,'medium','small');
  for(let i=0;i<10;i++){
    const v=M.demoSample(m,'small',20,i); v.sequence=i;
    const r=S.trainingPush(t,v,1000+i*200,M.validate);
    assert.equal(r.count,i+1);
  }
  assert.equal(S.trainingCommit(t,M.entry).length,10);
  assert.equal(S.trainingPush(t,{bad:true},4000,M.validate).status,'rejected');
}
let t=S.trainingStart('gold',10,'medium','small');let sample=M.demoSample('gold','small',10);sample.sequence=11;
assert.equal(S.trainingPush(t,sample,2000,M.validate).count,1);
assert.equal(S.trainingPush(t,sample,2300,M.validate).status,'duplicate');
assert.equal(S.trainingPush(t,{...sample,coil:'large',sequence:12},2400,M.validate).status,'rejected');
const ranked=S.topThree({ok:true,ranked:[{metal:'gold',score:70},{metal:'silver',score:20},{metal:'aluminum',score:10},{metal:'iron',score:0}]});
assert.deepEqual(ranked.map(x=>x.score),[70,20,10]);
assert.equal(S.topThree({ok:false,ranked:[]}).length,0);
const d=(minCm,maxCm)=>({ok:true,minCm,maxCm});
for(const args of [
  {enabled:true,mode:'real',detected:true,cutoffCm:50,depth:d(10,30),groundZero:true,heightCm:0},
  {enabled:true,mode:'real',detected:true,cutoffCm:50,depth:d(40,60),groundZero:true,heightCm:0},
  {enabled:true,mode:'real',detected:true,cutoffCm:50,depth:null,groundZero:true,heightCm:0},
  {enabled:true,mode:'real',detected:true,cutoffCm:50,depth:d(70,90),groundZero:false,heightCm:0},
  {enabled:true,mode:'real',detected:true,cutoffCm:50,depth:d(70,90),groundZero:true,heightCm:10},
  {enabled:true,mode:'phone',detected:true,cutoffCm:50,depth:d(70,90),groundZero:true,heightCm:0}
])assert.equal(S.gate(args).announce,false,S.gate(args).reason);
assert.equal(S.gate({enabled:true,mode:'real',detected:true,cutoffCm:50,depth:d(65,85),groundZero:true,heightCm:0}).announce,true);
assert.equal(S.gate({enabled:true,mode:'demo',detected:true,cutoffCm:50,demonstrationDistanceCm:20}).announce,false);
assert.equal(S.gate({enabled:true,mode:'demo',detected:true,cutoffCm:50,demonstrationDistanceCm:80}).announce,true);
assert.equal(S.gate({enabled:false,detected:true}).announce,true);
console.log('PASS Rev G: automatic learning, top3 similarity, depth filter, height/contact guards');

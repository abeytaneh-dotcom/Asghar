/* PI FieldLab Rev F: comparative time-domain signatures, NOT absolute metal chemistry.
   No inference from phone magnetometer/NFC or v1 strength-only frames.
   Depth is identifiable only relative to a measured target size/template and validated attenuation curve. */
(function(root,factory){const api=factory();if(typeof module!=='undefined'&&module.exports)module.exports=api;root.PIMetalID=api;})(typeof globalThis!=='undefined'?globalThis:this,()=>{'use strict';
const TIMES=[35,60,110,200,350];
const METALS={iron:'آهن / فولاد',copper:'مس / آلیاژهای مس',aluminum:'آلومینیوم',gold:'طلا / آلیاژ طلا',silver:'نقره / آلیاژ نقره'};
const SIZES={small:'کوچک',medium:'متوسط',large:'بزرگ'};
const bound=(n,a,b)=>Math.max(a,Math.min(b,n));
const finite=n=>typeof n==='number'&&Number.isFinite(n);
function crc16(data){let crc=0xffff;for(const val of data){crc^=val<<8;for(let i=0;i<8;i++)crc=((crc&0x8000)?(crc<<1)^0x1021:crc<<1)&0xffff;}return crc;}
function fromFrame(data){const a=data instanceof Uint8Array?data:new Uint8Array(data.buffer||data,data.byteOffset||0,data.byteLength||data.length);if(a.length!==20||a[0]!==0x50||a[1]!==0x46||a[2]!==2)throw Error('بسته پاسخ پالسی Rev F نامعتبر است');if(crc16(a.subarray(0,18))!==(a[18]|a[19]<<8))throw Error('CRC پاسخ پالسی نادرست است');const dv=new DataView(a.buffer,a.byteOffset,a.byteLength),flags=a[4];return {kind:'pi-spectrum-v2',sequence:a[3],coil:a[5]===1?'large':a[5]===0?'small':'invalid',values:TIMES.map((_,i)=>dv.getInt16(6+i*2,true)),noiseCounts:dv.getUint16(16,true),calibrated:!!(flags&1),fault:!!(flags&2),stable:!!(flags&4),backgroundRemoved:!!(flags&8),windowsUs:[...TIMES],receivedAt:Date.now()};}
function validate(raw){if(!raw||raw.kind!=='pi-spectrum-v2'||!['small','large'].includes(raw.coil)||!Array.isArray(raw.values)||raw.values.length!==5||raw.values.some(v=>!finite(v)||Math.abs(v)>32767)||!finite(raw.noiseCounts)||raw.noiseCounts<=0||raw.noiseCounts>65535||!Array.isArray(raw.windowsUs)||raw.windowsUs.length!==5||raw.windowsUs.some((v,i)=>v!==TIMES[i]))throw Error('۵ پنجره PI یا نویز معتبر وجود ندارد');let amp=Math.max(...raw.values.map(Math.abs)),snr=amp/raw.noiseCounts;if(raw.fault)throw Error('برد در حالت خطاست');if(!raw.calibrated||!raw.backgroundRemoved||!raw.stable)throw Error('نیاز به بالانس زمین و نمونه پایدار');if(snr<7)throw Error('SNR کمتر از ۷ است؛ تفکیک قابل‌اعتماد نیست');return {...raw,amp,snr};}
function signature(raw){const r=validate(raw),noise=r.noiseCounts;const ref=Math.log1p(Math.abs(r.values[0])/noise);return r.values.slice(1).map(v=>Math.log1p(Math.abs(v)/noise)-ref);}
function entry(raw,label,depthCm,size){const r=validate(raw);if(!METALS[label]||!SIZES[size]||!finite(depthCm)||depthCm<0||depthCm>300)throw Error('نوع فلز، اندازه یا عمق مرجع معتبر نیست');return{metal:label,size,depthCm:+depthCm.toFixed(2),coil:r.coil,values:[...r.values],windowsUs:[...TIMES],noiseCounts:r.noiseCounts,calibrated:true,stable:true,backgroundRemoved:true,fault:false,kind:'pi-spectrum-v2',at:new Date().toISOString()};}
const dist=(a,b)=>Math.sqrt(a.reduce((s,x,i)=>s+(x-b[i])**2,0)/a.length);
const meanVectors=v=>v[0].map((_,i)=>v.reduce((s,x)=>s+x[i],0)/v.length);
function classification(raw,refs){const r=validate(raw),feature=signature(r),classes=Object.keys(METALS).map(metal=>{const examples=refs.filter(x=>x.metal===metal&&x.coil===r.coil).filter(x=>{try{validate(x);return true;}catch(_){return false;}});if(examples.length<3)return null;const features=examples.map(signature),center=meanVectors(features);return{metal,examples:examples.length,discrepancy:dist(feature,center),dispersion:features.reduce((s,v)=>s+dist(v,center),0)/features.length};}).filter(Boolean);
if(classes.length<2)return{ok:false,reason:'برای تفکیک واقعی حداقل دو گروه فلز و برای هر گروه ۳ نمونه کالیبره لازم است.'};
const ranked=classes.map(x=>({...x,weight:Math.exp(-Math.pow(x.discrepancy/0.145,2)/2)})).sort((a,b)=>b.weight-a.weight);
const top=ranked[0],second=ranked[1];if(top.discrepancy>Math.max(0.32,3*top.dispersion+0.08)||top.weight<second.weight*1.5)return{ok:false,reason:'الگوی پاسخ با مرجع‌ها هم‌خوانی کافی ندارد؛ نوع فلز نامعلوم است.',ranked};
const sum=ranked.reduce((a,x)=>a+x.weight,0);return{ok:true,metal:top.metal,label:METALS[top.metal],ranked:ranked.map(x=>({metal:x.metal,label:METALS[x.metal],score:Math.round(100*x.weight/sum),examples:x.examples})),note:'درصدها سهم شباهت به الگوهای مرجع‌اند، نه احتمال قطعی یا شناسایی شیمیایی.'};}
function depth(raw,refs,metal,size){const r=validate(raw);if(!METALS[metal]||!SIZES[size])return{ok:false,reason:'اندازه تقریبی هدف باید مشخص باشد'};
const samples=refs.filter(x=>x.coil===r.coil&&x.metal===metal&&x.size===size).filter(x=>{try{validate(x);return true;}catch(_){return false;}});
const distinct=[...new Set(samples.map(x=>x.depthCm))];if(distinct.length<3||Math.max(...distinct)-Math.min(...distinct)<15)return{ok:false,reason:'برای تخمین عمق، حداقل ۳ فاصله کالیبره با اختلاف مجموع دست‌کم ۱۵ سانتی‌متر برای همین اندازه هدف لازم است.'};
const points=distinct.map(d=>{const ss=samples.filter(x=>x.depthCm===d),arr=ss.map(x=>Math.log(Math.max(...x.values.map(Math.abs))));return{x:d,y:arr.reduce((a,b)=>a+b,0)/arr.length};});
const mx=points.reduce((a,p)=>a+p.x,0)/points.length,my=points.reduce((a,p)=>a+p.y,0)/points.length;
const num=points.reduce((a,p)=>a+(p.x-mx)*(p.y-my),0),den=points.reduce((a,p)=>a+(p.x-mx)**2,0),slope=num/den,intercept=my-slope*mx;
const rss=points.reduce((a,p)=>a+(p.y-intercept-slope*p.x)**2,0),tss=points.reduce((a,p)=>a+(p.y-my)**2,0),r2=tss>0?1-rss/tss:0;
if(!(slope<-.002&&r2>=.85))return{ok:false,reason:'منحنی افت سیگنال کالیبراسیون یکنواخت یا قابل‌اعتماد نیست.'};
const x=(Math.log(r.amp)-intercept)/slope;const min=Math.min(...distinct),max=Math.max(...distinct);
if(x<min||x>max)return{ok:false,reason:'سیگنال خارج از محدوده عمق‌های کالیبره‌شده است؛ برون‌یابی ممنوع.'};
const std=Math.sqrt(rss/Math.max(1,points.length-2)),uncertainty=Math.max(6,std/Math.abs(slope)*2,x*.18);
return{ok:true,centerCm:Math.round(x),minCm:Math.round(bound(x-uncertainty,min,max)),maxCm:Math.round(bound(x+uncertainty,min,max)),fitR2:+r2.toFixed(2),assumedSize:size,referenceDepth:[min,max],note:'فاصله مشروط به فرض اندازه/شکل مشابه نمونه مرجع و ارتفاع ثابت لوپ؛ عمق حقیقی قطعی نیست.'};}
function demoSample(metal,coil,depthCm,sequence=0){if(!METALS[metal])metal='iron';const decay={iron:165,copper:106,aluminum:64,gold:89,silver:138}[metal];const amp=(coil==='large'?850:650)/Math.pow(1+depthCm/(coil==='large'?52:32),2);return{kind:'pi-spectrum-v2',values:TIMES.map((t,i)=>Math.round(amp*Math.exp(-t/decay)*(1+.013*Math.sin(sequence*.4+i*2)))),windowsUs:[...TIMES],noiseCounts:2,coil,calibrated:true,stable:true,backgroundRemoved:true,fault:false};}
function demoReferences(coil){const refs=[];for(const metal of Object.keys(METALS)){for(const d of [10,20,35,50]){const v=demoSample(metal,coil,d,2+d);refs.push(entry(v,metal,d,'medium'));}}return refs;}
return{TIMES,METALS,SIZES,crc16,fromFrame,validate,signature,entry,classification,depth,demoSample,demoReferences};
});

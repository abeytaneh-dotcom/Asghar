/* PI FieldLab Rev G. Automatic recognition from external PI multi-window signatures only.
   Training labels are specified once for known reference objects, NEVER during detection.
   Depth gating is conservative and silent if a calibrated estimate is not available. */
(()=>{'use strict';
const $=x=>document.getElementById(x),M=window.PIMetalID,S=window.PIMetalSmart;
const key='pi-fieldlab-revF-calibration';
let refs=(()=>{try{const v=JSON.parse(localStorage.getItem(key)||'[]');return Array.isArray(v)?v.filter(x=>{try{M.validate(x);return true;}catch(_){return false;}}).slice(-900):[];}catch(_){return[];}})();
let latest=null,source='demo',lastSpectrumAt=0,lastReading=null,training=null,groundZero=false,selectedDemo='iron',pendingDemo=null,lastNotifyAt=0;
const mode=()=>$('phoneMode').classList.contains('selected')?'phone':$('realMode').classList.contains('selected')?'real':'demo';
const notify=x=>{$('metalMessage').textContent=x;};
function saveRefs(){try{localStorage.setItem(key,JSON.stringify(refs));}catch(e){notify('فضای ذخیره‌سازی کافی نیست: '+e.message);}}
function updateCalCount(){const types=new Set(refs.map(x=>x.metal+'|'+x.coil));$('metalCalibrationCount').textContent=`${refs.length} برداشت از ${types.size} گروه/لوپ ثبت شده`}
function resetText(msg){$('metalClass').textContent='نامعلوم';$('metalScore').textContent='—';$('metalDepth').textContent='—';$('metalScores').innerHTML='';notify(msg);}
function drawBars(result){$('metalScores').innerHTML=S.topThree(result).map(x=>`<div class="metal-bar"><span>${x.label}</span><div><i style="width:${x.score}%"></i></div><strong>${x.score}٪</strong></div>`).join('');}
function updateGate(sample,reading,estimated){
 const current=mode(),enabled=$('depthGateOn').checked,cutoff=Number($('depthGateValue').value);
 const height=Number($('measuredHeight').value),isDetected=!!(reading?.detected);
 const response=S.gate({enabled,cutoffCm:cutoff,mode:current,detected:isDetected,depth:estimated,groundZero,heightCm:height,demonstrationDistanceCm:current==='demo'?Number($('depth').value):null});
 $('depthGateStatus').textContent=(enabled?'فیلتر فعال: ':'فیلتر خاموش: ')+response.reason+(enabled&&current==='demo'?' — فقط داده نمایشی':'');
 if(enabled&&isDetected){
  const hero=$('hero'),label=$('detLabel');
  if(!response.announce){hero.classList.remove('detection');label.textContent='سیگنال ثبت شد؛ هشدار عمقی خاموش';}
  else{hero.classList.add('detection');label.textContent=current==='demo'?'هدف نمایشی پس از فیلتر':'هدف محتمل پس از فیلتر عمق';}
 }
 document.dispatchEvent(new CustomEvent('pi:depth-gate',{detail:{...response,mode:current,enabled,cutoffCm:cutoff,estimatedDepthCm:estimated?.ok?estimated:null}}));
 return response;
}
function useSample(s,src,reading=lastReading){latest=s;source=src;let c,estimated=null;
 try{const valid=M.validate(s);const reference=src==='demo'?M.demoReferences(valid.coil):refs;c=M.classification(valid,reference);}catch(e){resetText(e.message);updateGate(null,reading,null);return;}
 if(!c.ok){resetText(c.reason);updateGate(null,reading,null);return;}
 $('metalClass').textContent=c.label;$('metalScore').textContent=(S.topThree(c)[0]?.score??'—')+'٪ سهم انطباق';drawBars(c);
 if(src==='demo'){
  $('metalDepth').textContent='—';notify('صرفاً شبیه‌سازی؛ اعداد نشان‌دهنده سهم تطبیق الگوهای ساختگی‌اند. عمق اسلایدر اندازه‌گیری نمی‌شود.');
  updateGate(s,reading,null);return;
 }
 estimated=M.depth(s,refs,c.metal,$('metalAssumedSize').value);
 $('metalDepth').textContent=estimated.ok?`${estimated.minCm} تا ${estimated.maxCm} سانتی‌متر`:'نامعلوم';
 const filter=updateGate(s,reading,estimated);
 notify(estimated.ok?`بازه تقریبی با فرض اندازه ${M.SIZES[estimated.assumedSize]}، هندسه مرجع مشابه و تماس با زمین (R²=${estimated.fitR2}). ${filter.enabled?'':''} درصدها احتمال شیمیایی نیستند.`:`${estimated.reason} درصدها فقط سهم انطباق‌اند؛ جنس و عمق قطعی نیستند.`);
}
function syncMode(){const m=mode();$('metalDemoSelect').closest('label').hidden=m!=='demo';$('autoRecognitionNote').textContent=m==='real'?'تشخیص هنگام کاوش کاملاً خودکار است؛ فقط در بخش آموزش مرجع نوع فلز انتخاب می‌شود.':m==='phone'?'گوشی فاقد گیرنده طیف PI است؛ NFC و مغناطیس‌سنج قادر به تفکیک طلا/نقره/عمق نیستند.':'دمو: انتخاب فلز فقط برای تولید داده ساختگی است؛ شناسایی واقعی نیست.';}
function captureTraining(s,at){if(!training)return;
 const status=S.trainingPush(training,s,at,M.validate);
 $('metalTrainingBar').style.width=Math.round((status.count||0)/S.TRAIN_READINGS*100)+'%';
 if(status.status==='rejected'){$('metalTrainingStatus').textContent=`رد برداشت: ${status.message} (${status.count}/${S.TRAIN_READINGS})`;return;}
 if(status.status==='collecting')$('metalTrainingStatus').textContent=`در حال آموزش ${M.METALS[training.label]}: ${status.count} از ${S.TRAIN_READINGS} نمونه واقعی`;
 if(status.status==='complete'){
  try{const records=S.trainingCommit(training,M.entry);refs.push(...records);refs=refs.slice(-900);saveRefs();updateCalCount();$('metalTrainingStatus').textContent=`✓ ${records.length} برداشت برای ${M.METALS[training.label]} ثبت شد. برای تفکیک مقایسه‌ای باید نمونه سایر گروه‌های فلز هم ثبت شود.`;}
  catch(e){$('metalTrainingStatus').textContent='خطا در ذخیره: '+e.message;}
  training=null;
 }
}
function readingHandler(e){const v=e.detail;if(!v)return;syncMode();lastReading=v;const md=v.source;
 if(md==='phone'){
  latest=null;resetText('حسگرهای گوشی فقط تغییر میدان یا تگ NFC را می‌خوانند؛ جنس فلز و عمق قابل اندازه‌گیری نیست.');updateGate(null,v,null);return;
 }
 if(md==='demo'){
  if(v.target==='none'||!v.detected){latest=null;resetText('در شبیه‌سازی هدفی شناسایی نشده.');updateGate(null,v,null);return;}
  pendingDemo=M.demoSample(selectedDemo,v.coil,v.depthTestCm??30,Math.round(v.when/1000));useSample(pendingDemo,'demo',v);return;
 }
 if(md==='real'){
  if(!v.connected||v.fault){training=null;latest=null;resetText('برد قطع است یا خطا دارد؛ آموزش و تشخیص متوقف شد.');updateGate(null,v,null);return;}
  if(!v.spectrum){
    if(Date.now()-lastSpectrumAt>2500){latest=null;resetText('فریم PI قدیمی شدت کلی دارد؛ برای آموزش/تفکیک، ۵ پنجره زمانی PF v2 لازم است.');updateGate(null,v,null);}return;
  }
  lastSpectrumAt=Date.now();captureTraining(v.spectrum,Date.now());useSample(v.spectrum,'real',v);
 }
}
document.addEventListener('pi:reading',readingHandler);
$('metalDemoSelect').addEventListener('change',e=>{selectedDemo=e.target.value;if(mode()==='demo'&&pendingDemo)useSample(M.demoSample(selectedDemo,pendingDemo.coil,Number($('depth').value),10),'demo',lastReading);});
$('metalAssumedSize').addEventListener('change',()=>{if(latest)useSample(latest,source,lastReading);});
$('metalTrainStart').addEventListener('click',()=>{
 if(mode()!=='real'||!lastReading?.connected||!latest||source!=='real'){$('metalTrainingStatus').textContent='آموزش نیازمند برد PI واقعی متصل و بسته معتبر PF v2 است؛ نزدیک کردن طلا به گوشی کافی نیست.';return;}
 try{const test=M.validate(latest);training=S.trainingStart($('metalReference').value,Number($('metalKnownDepth').value),$('metalAssumedSize').value,test.coil);$('metalTrainingBar').style.width='0%';$('metalTrainingStatus').textContent=`آموزش ${M.METALS[training.label]} آغاز شد. نمونه را با فاصله ثابت مقابل لوپ نگه دار؛ ۱۰ فریم مستقل ذخیره می‌شود.`;}catch(e){$('metalTrainingStatus').textContent=e.message;}
});
$('metalTrainCancel').addEventListener('click',()=>{training=null;$('metalTrainingBar').style.width='0%';$('metalTrainingStatus').textContent='آموزش لغو شد؛ نمونه ناقص ذخیره نشد.';});
$('metalCalSave').addEventListener('click',()=>{
 if(mode()!=='real'||source!=='real'||!lastReading?.connected||!latest){notify('فقط سیگنال واقعی برد PI متصل را به‌عنوان مرجع ثبت می‌کنیم.');return;}
 try{const record=M.entry(latest,$('metalReference').value,Number($('metalKnownDepth').value),$('metalAssumedSize').value);refs.push(record);refs=refs.slice(-900);saveRefs();updateCalCount();notify('یک برداشت واقعی ثبت شد؛ آموزش چندنمونه‌ای برای پایداری بهتر است.');}catch(e){notify(e.message);}
});
$('metalCalClear').addEventListener('click',()=>{if(!confirm('همه نمونه‌های مرجع ذخیره‌شده از گوشی پاک شوند؟'))return;refs=[];training=null;localStorage.removeItem(key);updateCalCount();resetText('نمونه‌های آموزش حذف شدند.');});
$('metalCalExport').addEventListener('click',()=>{const content=JSON.stringify({format:'pi-metal-cal-v2',createdAt:new Date().toISOString(),samples:refs},null,2);if(window.PhoneBridge?.saveText)window.PhoneBridge.saveText('pi-metal-references.json','application/json',content);else{const blob=new Blob([content],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='pi-metal-references.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}});
$('metalRawImport').addEventListener('change',async e=>{try{const file=e.target.files[0];if(!file)return;const raw=JSON.parse(await file.text()),obj=raw.spectrum||raw;M.validate(obj);useSample(obj,'import',lastReading);notify('فایل آزمایشگاهی وارد شد؛ منبع و مقادیر آن به صورت مستقل تأیید نشده است. '+$('metalMessage').textContent);}catch(ex){resetText('فایل نمونه نامعتبر: '+ex.message);}finally{e.target.value='';}});
$('metalRawOpen').onclick=()=>$('metalRawImport').click();
function renderHeight(){const n=Number($('measuredHeight').value);$('heightStatus').textContent=groundZero?(n<=3?`صفر ارتفاع از تماس با زمین با تأیید کاربر ثبت شد؛ ارتفاع کنونیِ دستی: ${n} cm. اندازه‌گیری ارتفاع خودکار نیست.`:'ارتفاع تغییر کرده است؛ بدون سنسور فاصله‌سنج/کالیبراسیون مجدد، فیلتر عمق واقعی فعال نمی‌شود.'):'صفر ارتفاع ثبت نشده؛ گوشی به‌تنهایی ارتفاع لوپ را با دقت سانتی‌متری نمی‌سنجد.';if(lastReading)updateGate(latest,lastReading,null);}
$('groundZeroButton').onclick=()=>{groundZero=true;$('measuredHeight').value='0';$('heightStatus').textContent='مبنای ارتفاع ۰ cm براساس قراردادن فیزیکی گوشی/لوپ روی زمین ثبت شد. تماس خودکار تأیید نشده است.';if(lastReading){if(latest)useSample(latest,source,lastReading);else updateGate(null,lastReading,null);}};
$('measuredHeight').oninput=()=>{const n=Number($('measuredHeight').value);if(!Number.isFinite(n)||n<0||n>100){$('measuredHeight').value='0';}renderHeight();if(lastReading&&latest)useSample(latest,source,lastReading);};
$('depthGateOn').onchange=()=>{if(latest)useSample(latest,source,lastReading);else updateGate(null,lastReading,null);};
$('depthGateValue').oninput=()=>{$('depthGateOut').textContent=$('depthGateValue').value;if(latest)useSample(latest,source,lastReading);else updateGate(null,lastReading,null);};
window.PIMetalPanel={onSpectrum:(raw)=>{try{useSample(raw,'real',lastReading);}catch(e){resetText(e.message);}},onDisconnect:()=>{latest=null;lastSpectrumAt=0;training=null;groundZero=false;resetText('BLE قطع شد؛ اطلاعات قبلی نباید به‌عنوان تشخیص جدید نمایش داده شود.');$('depthGateStatus').textContent='ارتباط واقعی قطع است؛ هشدار خاموش می‌ماند.';}};
updateCalCount();resetText('برای نمایش خودکار، نمونه‌های مرجع واقعی با لوپ ثبت کن؛ دمو جداگانه قابل آزمایش است.');syncMode();
})();

/* Rev G: pure policy and learning logic. No material identity from phone NFC/magnetometer.
   Label percentages are relative template-matching scores, never chemical probabilities.
   A range is only usable for filtering if calibrated and the coil is on its ground-contact reference. */
(function(root,factory){const api=factory();if(typeof module!=='undefined'&&module.exports)module.exports=api;root.PIMetalSmart=api;})(typeof globalThis!=='undefined'?globalThis:this,()=>{'use strict';
const TRAIN_READINGS=10;
const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
function trainingStart(label,depthCm,size,coil){
 if(!['gold','silver','aluminum','copper','iron'].includes(label))throw Error('فلز مرجع مشخص نیست');
 if(!Number.isFinite(depthCm)||depthCm<0||depthCm>300)throw Error('فاصله مرجع نامعتبر است');
 if(!['small','medium','large'].includes(size)||!['small','large'].includes(coil))throw Error('پروفایل مرجع نامعتبر است');
 return {label,depthCm,size,coil,measurements:[],lastAt:0,lastSeq:null,startedAt:Date.now()};
}
function trainingPush(training,spectrum,at,validate){
 if(!training)return {status:'inactive',count:0};
 try{validate(spectrum);}catch(e){return {status:'rejected',message:e.message,count:training.measurements.length};}
 if(spectrum.coil!==training.coil)return {status:'rejected',message:'لوپ در حین آموزش تغییر کرد',count:training.measurements.length};
 if(typeof spectrum.sequence==='number'&&training.lastSeq===spectrum.sequence)return {status:'duplicate',count:training.measurements.length};
 if(at-training.lastAt<120)return {status:'too-soon',count:training.measurements.length};
 training.measurements.push({...spectrum,values:[...spectrum.values]});training.lastAt=at;
 if(typeof spectrum.sequence==='number')training.lastSeq=spectrum.sequence;
 return {status:training.measurements.length>=TRAIN_READINGS?'complete':'collecting',count:training.measurements.length,target:TRAIN_READINGS};
}
function trainingCommit(training,entry){
 if(!training||training.measurements.length<TRAIN_READINGS)throw Error('نمونه‌گیری مرجع کامل نیست');
 return training.measurements.map(s=>entry(s,training.label,training.depthCm,training.size));
}
function topThree(result){
 if(!result||!result.ok||!Array.isArray(result.ranked))return [];
 const selected=result.ranked.slice(0,3);let total=selected.reduce((s,r)=>s+r.score,0);
 if(total<=0)return [];
 const weights=selected.map(r=>100*r.score/total);
 const v=weights.map(Math.floor),diff=100-v.reduce((s,x)=>s+x,0);
 const order=weights.map((w,i)=>({i,r:w-v[i]})).sort((a,b)=>b.r-a.r);
 for(let n=0;n<diff;n++)v[order[n%order.length].i]++;
 return selected.map((r,i)=>({...r,score:v[i]}));
}
function gate({enabled=false,cutoffCm=50,mode='real',detected=false,depth=null,groundZero=false,heightCm=0,demonstrationDistanceCm=null}={}){
 if(!detected)return {announce:false,kind:'no-target',reason:'سیگنال هدف معتبر نیست'};
 if(!enabled)return {announce:true,kind:'off',reason:'فیلتر عمق خاموش است'};
 const cut=clamp(Number(cutoffCm)||0,0,300);
 if(mode==='demo'){
  if(!Number.isFinite(demonstrationDistanceCm))return {announce:false,kind:'unknown',reason:'فاصله نمایشی نامشخص است'};
  return demonstrationDistanceCm<cut?{announce:false,kind:'near',reason:`هدف نمایشی در فاصله کمتر از ${cut} سانتی‌متر فیلتر شد`}:{announce:true,kind:'far',reason:'فقط آزمایش نمایشی فیلتر عمق'};
 }
 if(mode!=='real')return {announce:false,kind:'unsupported',reason:'حسگر گوشی توان تخمین عمق هدف را ندارد'};
 if(!groundZero)return {announce:false,kind:'unknown',reason:'ابتدا مرجع ارتفاع صفر را روی زمین ثبت کن'};
 if(!Number.isFinite(heightCm)||heightCm>3||heightCm<0)return {announce:false,kind:'height',reason:'ارتفاع از محدوده تماس با زمین خارج است؛ برای فیلتر عمق باید ارتفاع معتبر باشد'};
 if(!depth?.ok||!Number.isFinite(depth.minCm)||!Number.isFinite(depth.maxCm)||depth.minCm>depth.maxCm)return {announce:false,kind:'unknown',reason:'عمق کالیبره و قابل‌اتکا در دسترس نیست؛ هشدار خاموش می‌ماند'};
 if(depth.maxCm<cut)return {announce:false,kind:'near',reason:`تمام بازه عمق (${depth.minCm}–${depth.maxCm}) نزدیک‌تر از ${cut} سانتی‌متر است`};
 if(depth.minCm>=cut)return {announce:true,kind:'far',reason:`بازه عمق کالیبره‌شده ${depth.minCm}–${depth.maxCm} سانتی‌متر از آستانه عبور می‌کند`};
 return {announce:false,kind:'crosses',reason:`بازه عمق ${depth.minCm}–${depth.maxCm} از مرز ${cut} سانتی‌متر عبور می‌کند؛ هشدار صادر نمی‌شود`};
}
return {TRAIN_READINGS,trainingStart,trainingPush,trainingCommit,topThree,gate};
});

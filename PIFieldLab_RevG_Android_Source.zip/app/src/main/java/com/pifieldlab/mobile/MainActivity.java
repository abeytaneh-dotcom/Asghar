package com.pifieldlab.mobile;

import android.app.Activity;
import android.Manifest;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.content.pm.PackageManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import java.util.UUID;
import android.os.Bundle;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.util.Base64;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Offline-only hybrid shell. NFC detects NFC tags, NOT generic metal. */
public final class MainActivity extends Activity implements SensorEventListener {
    private WebView web;
    private SensorManager sensors;
    private Sensor magneticSensor;
    private NfcAdapter nfc;
    private boolean magEnabled = false, nfcEnabled = false;
    private static final int REQ_BLE = 413;
    private static final UUID BLE_SERVICE = UUID.fromString("6edcdb01-944b-4c10-b2c4-6fc97fe0bb31");
    private static final UUID BLE_NOTIFY = UUID.fromString("6edcdb02-944b-4c10-b2c4-6fc97fe0bb31");
    private static final UUID BLE_WRITE = UUID.fromString("6edcdb03-944b-4c10-b2c4-6fc97fe0bb31");
    private static final UUID BLE_CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private final Handler handler = new Handler(Looper.getMainLooper());
    private BluetoothLeScanner bleScanner;
    private BluetoothGatt bleGatt;
    private BluetoothGattCharacteristic bleControl;
    private ScanCallback bleScanCallback;
    private boolean bleConnected = false;
    private byte[] pendingBytes = null;
    private String pendingMime = "text/plain";
    private static final int SAVE_DOCUMENT = 301;
    private static final int PICK_SAMPLE = 302;
    private ValueCallback<Uri[]> chooserCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        sensors = (SensorManager)getSystemService(SENSOR_SERVICE);
        magneticSensor = sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        nfc = NfcAdapter.getDefaultAdapter(this);
        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(false);
        ws.setAllowFileAccessFromFileURLs(false);
        ws.setAllowUniversalAccessFromFileURLs(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return !"file".equals(req.getUrl().getScheme());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(chooserCallback!=null)chooserCallback.onReceiveValue(null);
                chooserCallback=callback;
                try { Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);in.addCategory(Intent.CATEGORY_OPENABLE);
                    in.setType("application/json");startActivityForResult(in,PICK_SAMPLE);return true;
                } catch(Exception e){chooserCallback=null;callback.onReceiveValue(null);return false;}
            }
            @Override public boolean onJsConfirm(WebView view,String url,String message,JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("تأیید",(d,w)->result.confirm())
                    .setNegativeButton("انصراف",(d,w)->result.cancel()).show();return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "PhoneBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void js(String code) {
        runOnUiThread(() -> { if(web != null) web.evaluateJavascript(code, null); });
    }
    private void bleStatus(String message, boolean connected) {
        js("window.PINativeBLE?.onStatus(" + JSONObject.quote(message) + "," + (connected?"true":"false") + ")");
    }
    private void blePacket(byte[] data) {
        if(data == null || data.length != 20) return;
        String encoded = Base64.encodeToString(data, Base64.NO_WRAP);
        js("window.PINativeBLE?.onPacket(" + JSONObject.quote(encoded) + ")");
    }
    private void requestBle() {
        if(Build.VERSION.SDK_INT >= 31) {
            if(checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED ||
               checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BLE);
                return;
            }
        } else if(Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BLE);
            return;
        }
        startBleScan();
    }
    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(req, perms, grants);
        if(req != REQ_BLE) return;
        boolean allowed = grants.length > 0;
        for(int n:grants) if(n != PackageManager.PERMISSION_GRANTED) allowed = false;
        if(allowed) startBleScan();
        else bleStatus("برای اتصال BLE باید مجوز دستگاه‌های نزدیک داده شود",false);
    }
    private void startBleScan() {
        try {
            stopBleInternal(false);
            BluetoothManager manager = (BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
            BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
            if(adapter == null || !adapter.isEnabled()) { bleStatus("بلوتوث گوشی را روشن کن",false);return; }
            bleScanner = adapter.getBluetoothLeScanner();
            if(bleScanner == null) { bleStatus("اسکنر BLE در دسترس نیست",false);return; }
            bleStatus("در حال جست‌وجوی PI-DUAL (تا ۱۲ ثانیه)…",false);
            bleScanCallback = new ScanCallback() {
                @Override public void onScanResult(int callbackType,ScanResult result) {
                    if(result == null || result.getDevice() == null) return;
                    String name = result.getScanRecord()!=null?result.getScanRecord().getDeviceName():null;
                    if(name == null) {try {name=result.getDevice().getName();}catch(SecurityException ignored){}}
                    if(name == null || !name.startsWith("PI-DUAL")) return;
                    BluetoothDevice device=result.getDevice();
                    runOnUiThread(()->{
                        stopScanOnly();
                        bleStatus("یافت شد: PI-DUAL؛ در حال اتصال…",false);
                        bleGatt=device.connectGatt(MainActivity.this,false,gattCallback,BluetoothDevice.TRANSPORT_LE);
                    });
                }
                @Override public void onScanFailed(int error) { bleStatus("خطای جست‌وجوی BLE: "+error,false); }
            };
            bleScanner.startScan(null,new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),bleScanCallback);
            handler.postDelayed(()->{if(bleScanCallback!=null){stopScanOnly();bleStatus("دستگاه PI-DUAL پیدا نشد",false);}},12000);
        } catch(Exception e) { bleStatus("BLE: "+e.getMessage(),false); }
    }
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g,int status,int newState) {
            if(status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                try {if(!g.discoverServices()) bleStatus("سرویس BLE یافت نشد",false);}catch(Exception e){bleStatus("خطای سرویس BLE",false);}
            } else if(newState == BluetoothProfile.STATE_DISCONNECTED) {
                bleConnected=false;bleControl=null;bleStatus("ارتباط BLE قطع شد",false);
                try{g.close();}catch(Exception ignored){}
            } else if(status!=BluetoothGatt.GATT_SUCCESS) {bleStatus("خطای GATT: "+status,false);try{g.close();}catch(Exception ignored){}}
        }
        @Override public void onServicesDiscovered(BluetoothGatt g,int status) {
            if(status!=BluetoothGatt.GATT_SUCCESS){bleStatus("خواندن سرویس BLE ناموفق بود",false);return;}
            android.bluetooth.BluetoothGattService svc=g.getService(BLE_SERVICE);
            if(svc==null){bleStatus("سرویس PI-DUAL وجود ندارد",false);return;}
            BluetoothGattCharacteristic telemetry=svc.getCharacteristic(BLE_NOTIFY);
            bleControl=svc.getCharacteristic(BLE_WRITE);
            if(telemetry==null||bleControl==null){bleStatus("مشخصات تله‌متری BLE کامل نیست",false);return;}
            try {
                if(!g.setCharacteristicNotification(telemetry,true)){bleStatus("اعلان‌های BLE فعال نشد",false);return;}
                BluetoothGattDescriptor cccd=telemetry.getDescriptor(BLE_CCCD);
                if(cccd==null){bleStatus("CCCD اعلان BLE وجود ندارد",false);return;}
                cccd.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                if(!g.writeDescriptor(cccd)){bleStatus("فعال‌کردن CCCD ناموفق بود",false);return;}
            } catch(Exception e){bleStatus("مشکل اعلان BLE: "+e.getMessage(),false);}
        }
        @Override public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int status) {
            if(BLE_CCCD.equals(d.getUuid()) && status==BluetoothGatt.GATT_SUCCESS) {
                bleConnected=true;bleStatus("PI-DUAL متصل؛ منتظر داده‌های سنسور…",true);
            } else bleStatus("دریافت اطلاعات BLE فعال نشد",false);
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c) {
            if(BLE_NOTIFY.equals(c.getUuid())) blePacket(c.getValue());
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value) {
            if(BLE_NOTIFY.equals(c.getUuid())) blePacket(value);
        }
    };
    private void stopScanOnly(){
        if(bleScanner!=null && bleScanCallback!=null) try{bleScanner.stopScan(bleScanCallback);}catch(Exception ignored){}
        bleScanCallback=null;
    }
    private void stopBleInternal(boolean report){
        stopScanOnly();bleConnected=false;bleControl=null;
        if(bleGatt!=null){try{bleGatt.disconnect();bleGatt.close();}catch(Exception ignored){}bleGatt=null;}
        if(report)bleStatus("BLE قطع شد؛ اطلاعات جدید دریافت نمی‌شود",false);
    }
    private void writeBleCommand(String b64) {
        if(!bleConnected || bleGatt==null || bleControl==null){bleStatus("برد PI وصل نیست",false);return;}
        try {
            byte[] b=Base64.decode(b64,Base64.DEFAULT);
            if(b.length!=8||b[0]!=(byte)0xc3||b[1]!=0x3c||b[2]<1||b[2]>5)return;
            if(Build.VERSION.SDK_INT>=33){bleGatt.writeCharacteristic(bleControl,b,BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);}
            else {bleControl.setValue(b);bleGatt.writeCharacteristic(bleControl);}
        } catch(Exception e){bleStatus("خطای ارسال BLE",false);}
    }
    private void startMag() {
        if(magneticSensor == null) { js("document.getElementById('phoneSensorStatus').textContent='این گوشی حسگر مغناطیسی ندارد'"); return; }
        magEnabled = sensors.registerListener(this, magneticSensor, SensorManager.SENSOR_DELAY_GAME);
    }
    private void stopMag() { magEnabled = false; sensors.unregisterListener(this, magneticSensor); }
    private final NfcAdapter.ReaderCallback readerCallback = new NfcAdapter.ReaderCallback() {
        @Override public void onTagDiscovered(Tag tag) {
            final byte[] id = tag.getId();
            StringBuilder hex = new StringBuilder();for(byte b: id)hex.append(String.format("%02X", b & 0xff));
            js("window.PIPhone?.onNativeNfc(" + JSONObject.quote(hex.toString()) + ",'NFC')");
        }
    };
    private void startNfcInternal() {
        if(nfc==null) { js("document.getElementById('phoneNfcStatus').textContent='NFC در این دستگاه وجود ندارد'");return; }
        if(!nfc.isEnabled()) { js("document.getElementById('phoneNfcStatus').textContent='ابتدا NFC را در تنظیمات اندروید روشن کن'");return; }
        nfcEnabled = true;
        nfc.enableReaderMode(this,readerCallback,
            NfcAdapter.FLAG_READER_NFC_A | NfcAdapter.FLAG_READER_NFC_B |
            NfcAdapter.FLAG_READER_NFC_F | NfcAdapter.FLAG_READER_NFC_V |
            NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,null);
    }
    private void stopNfcInternal(){ nfcEnabled = false; if(nfc!=null)nfc.disableReaderMode(this); }

    @Override public void onSensorChanged(SensorEvent ev){
        if(ev.sensor.getType()!=Sensor.TYPE_MAGNETIC_FIELD || !magEnabled)return;
        float x=ev.values[0],y=ev.values[1],z=ev.values[2];
        int a=ev.accuracy;
        js("window.PIPhone?.onNativeMagnetic("+x+","+y+","+z+","+a+")");
    }
    @Override public void onAccuracyChanged(Sensor s,int accuracy){}

    public final class Bridge {
        @JavascriptInterface public void startMagnetometer(){runOnUiThread(()->startMag());}
        @JavascriptInterface public void stopMagnetometer(){runOnUiThread(()->stopMag());}
        @JavascriptInterface public void startNfc(){runOnUiThread(()->startNfcInternal());}
        @JavascriptInterface public void connectBle(){runOnUiThread(()->requestBle());}
        @JavascriptInterface public void disconnectBle(){runOnUiThread(()->stopBleInternal(true));}
        @JavascriptInterface public void writeBle(String encoded){runOnUiThread(()->writeBleCommand(encoded));}
        @JavascriptInterface public void stopNfc(){runOnUiThread(()->stopNfcInternal());}
        @JavascriptInterface public void saveText(String name,String mime,String content){
            byte[] bytes=content.getBytes(StandardCharsets.UTF_8);runOnUiThread(()->save(name,mime,bytes));
        }
        @JavascriptInterface public void saveBase64(String name,String mime,String dataUrl){
            try{String data=dataUrl.substring(dataUrl.indexOf(',')+1);byte[] bytes=Base64.decode(data,Base64.DEFAULT);runOnUiThread(()->save(name,mime,bytes));}
            catch(Exception ignored){}
        }
    }
    private void save(String filename,String mime,byte[] bytes){
        pendingBytes=bytes;pendingMime=mime;
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE,filename);
        startActivityForResult(intent,SAVE_DOCUMENT);
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==PICK_SAMPLE){
            if(chooserCallback!=null){Uri[] value=(result==RESULT_OK&&data!=null&&data.getData()!=null)?new Uri[]{data.getData()}:null;
                chooserCallback.onReceiveValue(value);chooserCallback=null;}return;
        }
        if(req!=SAVE_DOCUMENT||result!=RESULT_OK||data==null||pendingBytes==null)return;
        Uri uri=data.getData();
        try(OutputStream stream=getContentResolver().openOutputStream(uri)){
            if(stream!=null)stream.write(pendingBytes);
            js("document.getElementById('phoneSensorStatus').textContent='فایل ذخیره شد'");
        }catch(Exception e){js("document.getElementById('phoneSensorStatus').textContent='خطای ذخیره فایل'");}
        finally{pendingBytes=null;}
    }
    @Override protected void onResume(){super.onResume();if(magEnabled&&magneticSensor!=null)sensors.registerListener(this,magneticSensor,SensorManager.SENSOR_DELAY_GAME);if(nfcEnabled&&nfc!=null&&nfc.isEnabled())startNfcInternal();}
    @Override protected void onPause(){stopBleInternal(true);if(nfc!=null)nfc.disableReaderMode(this);sensors.unregisterListener(this);super.onPause();}
    @Override protected void onDestroy(){stopBleInternal(false);stopMag();if(web!=null){web.removeJavascriptInterface("PhoneBridge");web.destroy();web=null;}super.onDestroy();}
}

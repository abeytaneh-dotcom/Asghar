#ifndef PI_SPECTRUM_V2_H
#define PI_SPECTRUM_V2_H
#include <stdint.h>
#include <stddef.h>
/* Transmit ONLY measured, settled, ground-subtracted ADC-window averages.
 * Offsets 35,60,110,200,350 us are experimental and MUST be verified against
 * the coil drain waveform, front-end clamp release and amplifier recovery.
 * Flags: bit0 baseline-calibrated, bit1 fault, bit2 stable sample, bit3 ground-subtracted.
 * 20 bytes fit default BLE ATT characteristic payload and old UART framing.
 */
uint16_t pi_crc16(const uint8_t* p,size_t len);
void pi_pack_spectrum_v2(uint8_t out[20],uint8_t sequence,uint8_t flags,uint8_t coil_id,
                         const int16_t settled_adc_counts[5],uint16_t noise_rms_adc_counts);
#endif

/* PI DualLoop ESP32-C3 BLE UART bridge — Arduino-ESP32 2.0.x
 * GPIO6 = RX from STM32 PA9 (UART_TX), GPIO7 = TX to STM32 PA10.
 * 3.3V only; dedicated buck capable of at least 500mA plus hardware headroom.
 * BLE NEVER enables TX, clears a fault, or bypasses the physical safety latch.
 */
#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <string>
static BLECharacteristic* notifyChar=nullptr;
static volatile bool connected=false;
static const char* SERVICE_UUID="6edcdb01-944b-4c10-b2c4-6fc97fe0bb31";
static const char* NOTIFY_UUID="6edcdb02-944b-4c10-b2c4-6fc97fe0bb31";
static const char* CONTROL_UUID="6edcdb03-944b-4c10-b2c4-6fc97fe0bb31";
static HardwareSerial MCU(1);
static uint16_t crc16(const uint8_t* p,size_t n){
 uint16_t v=0xffff;for(size_t i=0;i<n;i++){v^=(uint16_t)p[i]<<8;for(int bit=0;bit<8;bit++)v=(v&0x8000)?(uint16_t)((v<<1)^0x1021):(uint16_t)(v<<1);}return v;
}
static bool validCommand(const uint8_t* b){
 if(b[0]!=0xc3||b[1]!=0x3c||crc16(b,6)!=(uint16_t)(b[6]|(b[7]<<8)))return false;
 uint8_t op=b[2];uint16_t value=b[3]|(b[4]<<8);
 return op>=1&&op<=5?((op<=2)?value>=1&&value<=10:value==0):false;
}
static void sendStopToMCU(){
 uint8_t x[8]={0xc3,0x3c,5,0,0,0,0,0};uint16_t c=crc16(x,6);x[6]=c&255;x[7]=c>>8;MCU.write(x,8);
}
class ServerCallbacks:public BLEServerCallbacks{
 void onConnect(BLEServer*) override{connected=true;}
 void onDisconnect(BLEServer* s) override{connected=false;sendStopToMCU();s->getAdvertising()->start();}
};
class ControlCallbacks:public BLECharacteristicCallbacks{
 void onWrite(BLECharacteristic* c) override {
   std::string val=c->getValue();
   if(val.size()!=8)return;
   const uint8_t* p=(const uint8_t*)val.data();
   if(!validCommand(p))return;
   MCU.write(p,8);
 }
};
static uint8_t buff[20];static int collected=0;
void setup(){
 Serial.begin(115200);MCU.begin(115200,SERIAL_8N1,6,7);
 BLEDevice::init("PI-DUAL-01");BLEServer* server=BLEDevice::createServer();server->setCallbacks(new ServerCallbacks());
 BLEService* service=server->createService(SERVICE_UUID);
 notifyChar=service->createCharacteristic(NOTIFY_UUID,BLECharacteristic::PROPERTY_READ|BLECharacteristic::PROPERTY_NOTIFY);
 notifyChar->addDescriptor(new BLE2902());
 BLECharacteristic* ctrl=service->createCharacteristic(CONTROL_UUID,BLECharacteristic::PROPERTY_WRITE);
 ctrl->setCallbacks(new ControlCallbacks());service->start();
 BLEAdvertising* adv=BLEDevice::getAdvertising();adv->addServiceUUID(SERVICE_UUID);adv->setScanResponse(true);adv->start();
 Serial.println("PI-DUAL BLE bridge ready. Power stage starts DISARMED.");
}
void loop(){
 // Resynchronizing fixed 20-byte frame; CRC guards against UART noise/corruption.
 while(MCU.available()){
   uint8_t b=(uint8_t)MCU.read();
   if(collected==0&&b!='P')continue;
   if(collected==1&&b!='I'&&b!='F'){collected=(b=='P')?1:0;continue;}
   buff[collected++]=b;
   if(collected==20){
     if(((buff[1]=='I'&&buff[2]==1)||(buff[1]=='F'&&buff[2]==2)) &&
        crc16(buff,18)==(uint16_t)(buff[18]|(buff[19]<<8)) && connected){
       notifyChar->setValue(buff,20);notifyChar->notify();
     }
     collected=0;
   }
 }
 delay(1);
}

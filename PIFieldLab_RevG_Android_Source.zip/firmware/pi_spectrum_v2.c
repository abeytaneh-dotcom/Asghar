#include "pi_spectrum_v2.h"
uint16_t pi_crc16(const uint8_t* p,size_t len) {
    uint16_t crc=0xffff;
    for(size_t i=0;i<len;i++) {
        crc^=(uint16_t)p[i]<<8;
        for(int k=0;k<8;k++)crc=(crc&0x8000)?(uint16_t)((crc<<1)^0x1021):(uint16_t)(crc<<1);
    }
    return crc;
}
void pi_pack_spectrum_v2(uint8_t out[20],uint8_t seq,uint8_t flags,uint8_t coil_id,
                         const int16_t adc[5],uint16_t noise) {
    out[0]='P';out[1]='F';out[2]=2;out[3]=seq;
    out[4]=flags;out[5]=coil_id;
    for(int i=0;i<5;i++) {uint16_t v=(uint16_t)adc[i];out[6+2*i]=v&255;out[7+2*i]=v>>8;}
    out[16]=noise&255;out[17]=noise>>8;
    uint16_t crc=pi_crc16(out,18);out[18]=crc&255;out[19]=crc>>8;
}

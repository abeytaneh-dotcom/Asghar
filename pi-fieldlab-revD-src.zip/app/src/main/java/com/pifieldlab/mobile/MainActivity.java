package com.pifieldlab.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.util.Base64;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Offline-only hybrid shell. NFC detects NFC tags, NOT generic metal. */
public final class MainActivity extends Activity implements SensorEventListener {
    private WebView web;
    private SensorManager sensors;
    private Sensor magneticSensor;
    private NfcAdapter nfc;
    private boolean magEnabled = false, nfcEnabled = false;
    private byte[] pendingBytes = null;
    private String pendingMime = "text/plain";
    private static final int SAVE_DOCUMENT = 301;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        sensors = (SensorManager)getSystemService(SENSOR_SERVICE);
        magneticSensor = sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        nfc = NfcAdapter.getDefaultAdapter(this);
        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(false);
        ws.setAllowFileAccessFromFileURLs(false);
        ws.setAllowUniversalAccessFromFileURLs(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return !"file".equals(req.getUrl().getScheme());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
        });
        web.addJavascriptInterface(new Bridge(), "PhoneBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void js(String code) {
        runOnUiThread(() -> { if(web != null) web.evaluateJavascript(code, null); });
    }
    private void startMag() {
        if(magneticSensor == null) { js("document.getElementById('phoneSensorStatus').textContent='این گوشی حسگر مغناطیسی ندارد'"); return; }
        magEnabled = sensors.registerListener(this, magneticSensor, SensorManager.SENSOR_DELAY_GAME);
    }
    private void stopMag() { magEnabled = false; sensors.unregisterListener(this, magneticSensor); }
    private final NfcAdapter.ReaderCallback readerCallback = new NfcAdapter.ReaderCallback() {
        @Override public void onTagDiscovered(Tag tag) {
            final byte[] id = tag.getId();
            StringBuilder hex = new StringBuilder();for(byte b: id)hex.append(String.format("%02X", b & 0xff));
            js("window.PIPhone?.onNativeNfc(" + JSONObject.quote(hex.toString()) + ",'NFC')");
        }
    };
    private void startNfcInternal() {
        if(nfc==null) { js("document.getElementById('phoneNfcStatus').textContent='NFC در این دستگاه وجود ندارد'");return; }
        if(!nfc.isEnabled()) { js("document.getElementById('phoneNfcStatus').textContent='ابتدا NFC را در تنظیمات اندروید روشن کن'");return; }
        nfcEnabled = true;
        nfc.enableReaderMode(this,readerCallback,
            NfcAdapter.FLAG_READER_NFC_A | NfcAdapter.FLAG_READER_NFC_B |
            NfcAdapter.FLAG_READER_NFC_F | NfcAdapter.FLAG_READER_NFC_V |
            NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,null);
    }
    private void stopNfcInternal(){ nfcEnabled = false; if(nfc!=null)nfc.disableReaderMode(this); }

    @Override public void onSensorChanged(SensorEvent ev){
        if(ev.sensor.getType()!=Sensor.TYPE_MAGNETIC_FIELD || !magEnabled)return;
        float x=ev.values[0],y=ev.values[1],z=ev.values[2];
        int a=ev.accuracy;
        js("window.PIPhone?.onNativeMagnetic("+x+","+y+","+z+","+a+")");
    }
    @Override public void onAccuracyChanged(Sensor s,int accuracy){}

    public final class Bridge {
        @JavascriptInterface public void startMagnetometer(){runOnUiThread(()->startMag());}
        @JavascriptInterface public void stopMagnetometer(){runOnUiThread(()->stopMag());}
        @JavascriptInterface public void startNfc(){runOnUiThread(()->startNfcInternal());}
        @JavascriptInterface public void stopNfc(){runOnUiThread(()->stopNfcInternal());}
        @JavascriptInterface public void saveText(String name,String mime,String content){
            byte[] bytes=content.getBytes(StandardCharsets.UTF_8);runOnUiThread(()->save(name,mime,bytes));
        }
        @JavascriptInterface public void saveBase64(String name,String mime,String dataUrl){
            try{String data=dataUrl.substring(dataUrl.indexOf(',')+1);byte[] bytes=Base64.decode(data,Base64.DEFAULT);runOnUiThread(()->save(name,mime,bytes));}
            catch(Exception ignored){}
        }
    }
    private void save(String filename,String mime,byte[] bytes){
        pendingBytes=bytes;pendingMime=mime;
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE,filename);
        startActivityForResult(intent,SAVE_DOCUMENT);
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req!=SAVE_DOCUMENT||result!=RESULT_OK||data==null||pendingBytes==null)return;
        Uri uri=data.getData();
        try(OutputStream stream=getContentResolver().openOutputStream(uri)){
            if(stream!=null)stream.write(pendingBytes);
            js("document.getElementById('phoneSensorStatus').textContent='فایل ذخیره شد'");
        }catch(Exception e){js("document.getElementById('phoneSensorStatus').textContent='خطای ذخیره فایل'");}
        finally{pendingBytes=null;}
    }
    @Override protected void onResume(){super.onResume();if(magEnabled&&magneticSensor!=null)sensors.registerListener(this,magneticSensor,SensorManager.SENSOR_DELAY_GAME);if(nfcEnabled&&nfc!=null&&nfc.isEnabled())startNfcInternal();}
    @Override protected void onPause(){if(nfc!=null)nfc.disableReaderMode(this);sensors.unregisterListener(this);super.onPause();}
    @Override protected void onDestroy(){stopMag();if(web!=null){web.removeJavascriptInterface("PhoneBridge");web.destroy();web=null;}super.onDestroy();}
}

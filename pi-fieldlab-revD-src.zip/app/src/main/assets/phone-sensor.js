/* Web NFC only reads near-field NDEF tags. Magnetometer is an independent phone sensor. */
(() => {'use strict';
const $=id=>document.getElementById(id), core=window.PIPhoneCore;
const state=core.create();let mag=null, nfc=null, isActive=false, nfcActive=false, native=false, countNfc=0, lastNfc='';
const ready=()=>document.getElementById('phoneMode').classList.contains('selected');
const set=(id,s)=>$(id).textContent=s;
function onMag(x,y,z,accuracy=3){
 if(!ready()||!isActive)return;
 let data;
 try{data=core.observe(state,{x:Number(x),y:Number(y),z:Number(z)});}catch(e){set('phoneSensorStatus',e.message);return;}
 set('phoneField',data.field.toFixed(1));set('phoneDelta',data.delta===null?'—':data.delta.toFixed(1));set('phoneThreshold',data.threshold.toFixed(1));
 set('phoneSensorStatus',data.collecting?'در حال نمونه‌گیری از میدان زمینه؛ گوشی را بدون چرخاندن ثابت نگه دار…':!data.calibrated?'اندازه‌گیری فعال است؛ «تنظیم مبنا» را بزن':(data.detected?'تغییر میدان قابل‌توجه است؛ وجود فلز/عمق ثابت نشده':'اندازه‌گیری فعال؛ مبنا تنظیم شده؛ جهت گوشی را ثابت نگه دار')+(accuracy===0?' | دقت حسگر پایین':'') );
 window.PIPhoneReading?.({signal:data.delta??0,noise:data.noise,threshold:data.threshold,detected:data.detected,calibrated:data.calibrated,fault:false,coil:'small',battery:0,field:data.field});
}
async function start(){
 if(!ready()){$('phoneMode').click();}
 if(isActive)return;
 isActive=true;
 if(window.PhoneBridge?.startMagnetometer){
  native=true;window.PhoneBridge.startMagnetometer();set('phoneSensorStatus','اتصال حسگر بومی اندروید برقرار شد؛ تنظیم مبنا را بزن.');return;
 }
 if(!window.isSecureContext){isActive=false;set('phoneSensorStatus','برای حسگر مرورگر اتصال HTTPS لازم است؛ یا پروژه Android را نصب کن. فایل آفلاین فقط شبیه‌ساز را اجرا می‌کند.');return;}
 if(typeof Magnetometer==='undefined'){isActive=false;set('phoneSensorStatus','مرورگر API مغناطیس‌سنج ندارد. از نسخه بومی Android استفاده کن.');return;}
 try{mag=new Magnetometer({frequency:15});mag.addEventListener('reading',()=>onMag(mag.x,mag.y,mag.z));mag.addEventListener('error',e=>set('phoneSensorStatus','خطای حسگر: '+(e.error?.message||'عدم دسترسی')));mag.start();set('phoneSensorStatus','حسگر فعال شد؛ گوشی را ثابت نگه دار و تنظیم مبنا را بزن.');}
 catch(e){isActive=false;set('phoneSensorStatus','عدم دسترسی به مغناطیس‌سنج: '+e.message);}
}
function stop(){isActive=false;document.dispatchEvent(new CustomEvent('pi:phone-stopped')); if(mag){try{mag.stop()}catch(_){}mag=null;}if(window.PhoneBridge?.stopMagnetometer)window.PhoneBridge.stopMagnetometer();set('phoneSensorStatus','حسگر متوقف شد');}
function calibrate(){if(!isActive){set('phoneSensorStatus','ابتدا حسگر مغناطیسی را روشن کن');return;}core.calibrate(state);set('phoneSensorStatus','برای تقریباً ۲ ثانیه گوشی را ثابت نگه دار و از فلز دور کن.');}
function onNfc(id,kind='NFC'){countNfc++;lastNfc=String(id||'ناشناس').slice(0,32);set('phoneNfcStatus',`تگ واقعی ${kind} شناسایی شد (${countNfc} بار) · شناسه: ${lastNfc} · این فلزیابی نیست.`);}
async function startNfc(){
 if(nfcActive)return;
 if(!ready())$('phoneMode').click();
 if(window.PhoneBridge?.startNfc){window.PhoneBridge.startNfc();nfcActive=true;set('phoneNfcStatus','NFC بومی فعال است. یک تگ را پشت گوشی نزدیک آنتن قرار بده.');return;}
 if(!window.isSecureContext){set('phoneNfcStatus','Web NFC فقط در محیط امن HTTPS قابل اجراست. برای فایل آفلاین، نسخه Android را استفاده کن.');return;}
 if(!('NDEFReader'in window)){set('phoneNfcStatus','Web NFC این مرورگر را پشتیبانی نمی‌کند؛ از Android Chrome روی HTTPS یا برنامه بومی استفاده کن.');return;}
 try{nfc=new AbortController();const reader=new NDEFReader();reader.addEventListener('reading',event=>onNfc(event.serialNumber||'', 'NDEF'));reader.addEventListener('readingerror',()=>set('phoneNfcStatus','تگ نزدیک است اما NDEF قابل خواندن نیست.'));await reader.scan({signal:nfc.signal});nfcActive=true;set('phoneNfcStatus','NFC فعال است؛ تگ NDEF را چند سانتی‌متر نزدیک پشت گوشی بگیر.');}
 catch(e){nfcActive=false;set('phoneNfcStatus','فعال‌سازی NFC انجام نشد: '+e.message);}
}
function stopNfc(){if(nfc)nfc.abort();nfc=null;if(window.PhoneBridge?.stopNfc)window.PhoneBridge.stopNfc();nfcActive=false;set('phoneNfcStatus','NFC متوقف شد'+(countNfc?' · '+countNfc+' تگ ثبت‌شده':''));}
function stopAll(){stop();stopNfc();}
function capabilities(){set('phoneSensorStatus',`حسگر مرورگر: ${typeof Magnetometer==='undefined'?'موجود نیست':'قابل آزمایش'} | پل اندروید: ${window.PhoneBridge?'موجود':'موجود نیست'} | بستر امن: ${window.isSecureContext?'بله':'خیر'} | دقت میدان با نوع گوشی تغییر می‌کند`);set('phoneNfcStatus',`NFC مرورگر: ${'NDEFReader'in window?'قابل آزمایش':'موجود نیست'} | NFC بومی: ${window.PhoneBridge?'قابل آزمایش':'موجود نیست'} | برد معمول: چند سانتی‌متر`);}
window.PIPhone={start,stop,calibrate,stopAll,onNativeMagnetic:onMag,onNativeNfc:onNfc};
$('phoneStart').addEventListener('click',start);$('phoneStop').addEventListener('click',stop);$('phoneCalibrate').addEventListener('click',calibrate);$('nfcStart').addEventListener('click',startNfc);$('nfcStop').addEventListener('click',stopNfc);$('phoneTest').addEventListener('click',capabilities);$('phoneTrialDistance').addEventListener('input',e=>set('phoneTrialOut',e.target.value));
})();

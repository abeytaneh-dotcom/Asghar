/* Phone sensor processing: magnetic anomaly measurement only, no ranging or PI metal detection. */
(function(root,factory){const v=factory();if(typeof module==='object'&&module.exports)module.exports=v;root.PIPhoneCore=v;})(typeof globalThis!=='undefined'?globalThis:this,()=>{'use strict';
const hypot=(v)=>Math.hypot(v.x,v.y,v.z);
const finite=(n)=>typeof n==='number'&&Number.isFinite(n);
const valid=(v)=>v&&finite(v.x)&&finite(v.y)&&finite(v.z)&&Math.abs(v.x)<100000&&Math.abs(v.y)<100000&&Math.abs(v.z)<100000;
function create(){return{baseline:null,noise:1,collecting:false,samples:[],started:0,last:null};}
function calibrate(s,t=Date.now()){s.collecting=true;s.samples=[];s.started=t;s.baseline=null;s.noise=1;}
function median(a){const b=[...a].sort((x,y)=>x-y);return b[Math.floor(b.length/2)];}
function observe(s,v,t=Date.now()){
 if(!valid(v))throw Error('مقدار نامعتبر حسگر مغناطیسی');
 const mag=hypot(v);s.last={...v,magnitude:mag,at:t};
 if(s.collecting){
  s.samples.push({...v});
  if(t-s.started>=1800&&s.samples.length>=10){
   const b={x:median(s.samples.map(p=>p.x)),y:median(s.samples.map(p=>p.y)),z:median(s.samples.map(p=>p.z))};
   const resid=s.samples.map(p=>Math.hypot(p.x-b.x,p.y-b.y,p.z-b.z));
   s.baseline=b;s.noise=Math.max(0.25,median(resid)*1.4826);s.collecting=false;s.samples=[];
  }
 }
 const delta=s.baseline?Math.hypot(v.x-s.baseline.x,v.y-s.baseline.y,v.z-s.baseline.z):null;
 const threshold=Math.max(2.5,4*s.noise);
 return {field:mag,delta,noise:s.noise,threshold,detected:delta!==null&&delta>threshold,calibrated:!!s.baseline,collecting:s.collecting,at:t};
}
return{create,calibrate,observe,valid};
});

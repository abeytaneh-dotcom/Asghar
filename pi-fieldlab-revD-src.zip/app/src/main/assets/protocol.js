/* PI DualLoop BLE transport v1. The signal is NOT depth or metal identity. */
(function (root, factory) {
  const p = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = p;
  root.PIWire = p;
})(typeof globalThis !== 'undefined' ? globalThis : this, () => {
  const SERVICE = '6edcdb01-944b-4c10-b2c4-6fc97fe0bb31';
  const TELEMETRY = '6edcdb02-944b-4c10-b2c4-6fc97fe0bb31';
  const CONTROL = '6edcdb03-944b-4c10-b2c4-6fc97fe0bb31';
  function crc16(data) {
    let crc = 0xffff;
    for (const val of data) {
      crc ^= val << 8;
      for (let i=0;i<8;i++) crc = ((crc & 0x8000) ? ((crc << 1) ^ 0x1021) : crc << 1) & 0xffff;
    }
    return crc;
  }
  function bytesOf(v) {
    return v instanceof DataView ? new Uint8Array(v.buffer, v.byteOffset, v.byteLength) : new Uint8Array(v.buffer || v, v.byteOffset || 0, v.byteLength || v.length);
  }
  function decode(raw) {
    const a=bytesOf(raw);
    if(a.length!==20 || a[0]!==0x50 || a[1]!==0x49 || a[2]!==1) throw new Error('بسته داده ناشناخته است');
    if(crc16(a.subarray(0,18))!==(a[18]|a[19]<<8)) throw new Error('خطای CRC در اطلاعات');
    const dv=new DataView(a.buffer,a.byteOffset,a.byteLength), flags=a[3];
    return {detected:!!(flags&1),fault:!!(flags&2),armed:!!(flags&4),calibrated:!!(flags&8),
      coil:a[4]===1?'large':'small',sequence:a[5],signal:dv.getInt16(6,true)/10,
      threshold:dv.getUint16(8,true)/10,noise:dv.getUint16(10,true)/10,
      battery:dv.getUint16(12,true)/100,current:dv.getUint16(14,true)*10,
      adc:dv.getUint16(16,true)};
  }
  function command(op,value=0,sequence=0) {
    if(!Number.isInteger(op)||op<1||op>5||!Number.isInteger(value)||value<0||value>65535) throw new Error('فرمان نامعتبر');
    const arr=new Uint8Array(8);
    arr[0]=0xc3;arr[1]=0x3c;arr[2]=op;arr[3]=value&255;arr[4]=value>>8;arr[5]=sequence&255;
    const crc=crc16(arr.subarray(0,6));arr[6]=crc&255;arr[7]=crc>>8;
    return arr;
  }
  function synthetic(target,depthCm,coil,sensitivity,tick) {
    const power={none:0,coin:38,ring:25,plate:850,barrel:2600,tank:22000}[target]||0;
    const reach=coil==='large'?68:30;
    const coilFactor=coil==='large'?1.3:1;
    const signal=coilFactor*power/Math.pow(1+Math.pow(depthCm/reach,2),2);
    const noise=(1.05+(11-sensitivity)*0.18);
    const fluctuation=(Math.sin(tick*0.92)*0.61+Math.cos(tick*1.13)*0.44)*noise;
    const detected=signal>Math.max(3.4,noise*(7.4-sensitivity*0.35));
    return {signal:signal+fluctuation,noise,threshold:Math.max(3.4,noise*(7.4-sensitivity*.35)),
      detected,coil,battery:12.25,current:0,adc:Math.round(1900+signal+fluctuation),armed:false,fault:false,calibrated:true,sequence:tick%256};
  }
  return {SERVICE,TELEMETRY,CONTROL,crc16,decode,command,synthetic};
});

/* Rev C: spatially-registered 2.5-D response map; no unvalidated depth estimate. */
(function(root,factory){const M=factory();if(typeof module!=='undefined'&&module.exports)module.exports=M;root.PIScan=M;})(typeof globalThis!=='undefined'?globalThis:this,()=>{'use strict';
const version='pi-scan-grid-v1';
const allowed=[5,7,9,11];
const paths=(n)=>{const out=[];for(let y=0;y<n;y++)for(let k=0;k<n;k++)out.push({x:y%2===0?k:n-1-k,y});return out;};
const index=(x,y,n)=>y*n+x;
const clamp=(a,min,max)=>Math.min(max,Math.max(min,a));
const validNumber=n=>typeof n==='number'&&Number.isFinite(n);
function make(n=7,stepM=0.25,source='demo',coil='small'){
 if(!allowed.includes(n)||!validNumber(stepM)||stepM<.1||stepM>.6)throw Error('شبکه یا فاصله نامعتبر');
 if(!['demo','real','phone'].includes(source)||!['small','large'].includes(coil))throw Error('منبع/لوپ نامعتبر');
 return{format:version,createdAt:new Date().toISOString(),n,stepM,source,coil,points:Array(n*n).fill(null)};
}
function normalizeReading(r){
 if(!r||!validNumber(r.signal)||!validNumber(r.noise)||!validNumber(r.threshold)||r.noise<0||r.threshold<=0)throw Error('داده نامعتبر');
 // A strength metric for display, not a physical range or size estimate.
 return clamp(4*Math.log1p(Math.max(0,Math.abs(r.signal)-2*Math.max(0,r.noise))/Math.max(1,r.threshold)),0,25);
}
function add(scan,x,y,reading,metadata={}){
 if(!Number.isInteger(x)||!Number.isInteger(y)||x<0||y<0||x>=scan.n||y>=scan.n)throw Error('مختصات خارج شبکه');
 if(!reading||reading.fault||!reading.calibrated)throw Error('فقط داده بدون خطا و کالیبره ثبت می‌شود');
 const src=metadata.source||scan.source,coil=reading.coil||scan.coil;
 if(src!==scan.source||coil!==scan.coil)throw Error('منبع داده یا لوپ با اسکن مطابقت ندارد');
 const signal=Number(reading.signal),noise=Number(reading.noise),threshold=Number(reading.threshold),relative=normalizeReading({signal,noise,threshold});
 const p={x,y,xM:+(x*scan.stepM).toFixed(3),yM:+(y*scan.stepM).toFixed(3),signal:+signal.toFixed(4),noise:+noise.toFixed(4),threshold:+threshold.toFixed(4),relative:+relative.toFixed(4),detected:!!reading.detected,source:src,coil,at:new Date().toISOString()};
 scan.points[index(x,y,scan.n)]=p;return p;
}
const count=s=>s.points.filter(Boolean).length;
function next(scan){const order=paths(scan.n);return order.find(({x,y})=>!scan.points[index(x,y,scan.n)])||null;}
function peak(scan){return scan.points.filter(Boolean).sort((a,b)=>b.relative-a.relative)[0]||null;}
function validate(input){
 if(!input||input.format!==version||!allowed.includes(input.n)||!validNumber(input.stepM)||input.stepM<.1||input.stepM>.6||!Array.isArray(input.points)||input.points.length!==input.n*input.n||!['demo','real','phone'].includes(input.source)||!['small','large'].includes(input.coil))throw Error('فرمت فایل اسکن نامعتبر است');
 let scan=make(input.n,input.stepM,input.source,input.coil);scan.createdAt=typeof input.createdAt==='string'?input.createdAt:scan.createdAt;
 for(let i=0;i<input.points.length;i++){
  let p=input.points[i];if(p===null)continue;
  if(!p||!Number.isInteger(p.x)||!Number.isInteger(p.y)||index(p.x,p.y,input.n)!==i||p.source!==scan.source||p.coil!==scan.coil||!validNumber(p.relative)||p.relative<0||p.relative>25)throw Error('نقطه اسکن نامعتبر است');
  let r={signal:p.signal,noise:p.noise,threshold:p.threshold,coil:p.coil,detected:p.detected,calibrated:true,fault:false};
  let a=add(scan,p.x,p.y,r,{source:p.source});
  if(Math.abs(a.relative-p.relative)>.002)throw Error('مقادیر نقطه دستکاری یا ناسازگارند');
  a.at=typeof p.at==='string'?p.at:a.at;
 }
 return scan;
}
function simulate(scan,target,depthCm,seed=1){
 const power={none:0,coin:38,ring:25,plate:850,barrel:2600,tank:22000}[target]||0;
 const effective=scan.coil==='large'?68:30;
 const gain=scan.coil==='large'?1.3:1;
 const amplitude=gain*power/Math.pow(1+Math.pow(depthCm/effective,2),2);
 const cs=scan.n-1;
 for(let y=0;y<scan.n;y++)for(let x=0;x<scan.n;x++){
  const dx=(x-cs*.53),dy=(y-cs*.46);
  const spatial=Math.exp(-.5*((dx/(1.05+scan.n*.11))**2+(dy/(.85+scan.n*.09))**2));
  const distortion=.09*Math.exp(-.5*((x-cs*.14)**2+(y-cs*.82)**2));
  const jitter=(Math.sin((x+1)*13.73+(y+1)*9.37+seed)*.32+Math.cos((x+1)*4.63+(y+1)*11.26)*.21);
  const noise=1.6;
  let signal=amplitude*(spatial+distortion)+jitter*noise;
  let threshold=6;
  add(scan,x,y,{signal,noise,threshold,detected:signal>threshold,fault:false,calibrated:true,coil:scan.coil},{source:'demo'});
 }
 return scan;
}
function summary(s){const p=s.points.filter(Boolean),pk=peak(s),positive=p.filter(t=>t.relative>=1),strength=p.reduce((a,t)=>a+t.relative,0)/(p.length||1);return{count:p.length,total:s.n*s.n,coverage:p.length/(s.n*s.n),peak:pk,positiveCount:positive.length,meanRelative:strength,scanWidthM:(s.n-1)*s.stepM};}
return{version,allowed,paths,index,make,add,count,next,peak,validate,normalizeReading,simulate,summary};
});

/* UI for reversible, position-indexed 2.5D plots. Manual X/Y positioning required. */
(() => {'use strict';
const M=globalThis.PIScan,$=id=>document.getElementById(id);
const ui={source:'demo',coil:'small',last:null,connected:false,readingAt:0,selected:null,view:'3d',undo:[],yaw:-.63,pitch:.76,zoom:1,points:0};
let scan;
const saveKey='pi-fieldlab-map-v1';
function note(s){const t=$('toast');t.textContent=s;t.classList.add('visible');setTimeout(()=>t.classList.remove('visible'),3200)}
function getMode(){return $('phoneMode').classList.contains('selected')?'phone':$('realMode').classList.contains('selected')?'real':'demo'}
function initSession(){scan=M.make(Number($('gridSize').value),Number($('gridStep').value),getMode(),document.querySelector('[data-coil].active')?.dataset.coil||'small');ui.undo=[];ui.selected=M.next(scan);update();persist()}
function persist(){try{localStorage.setItem(saveKey,JSON.stringify(scan))}catch(_){}}
function restore(){try{const saved=localStorage.getItem(saveKey);if(!saved)return false;scan=M.validate(JSON.parse(saved));$('gridSize').value=String(scan.n);$('gridStep').value=String(scan.stepM);ui.selected=M.next(scan);return true}catch(e){return false}}
function currentCell(){return ui.selected||M.next(scan)}
function checkMode(){if(!scan)return;const m=getMode(),c=document.querySelector('[data-coil].active')?.dataset.coil||scan.coil;if(m!==scan.source||c!==scan.coil){if(M.count(scan)===0){scan.source=m;scan.coil=c;ui.undo=[];persist()}else{$('scanSource').textContent='منبع نقشه ذخیره‌شده: '+(scan.source==='demo'?'شبیه‌ساز':scan.source==='phone'?'مغناطیس‌سنج گوشی':'برد PI واقعی')+' / '+(scan.coil==='small'?'کوچک':'بزرگ')+'؛ برای ثبت در حالت جدید شبکه را پاک کن';return;} }update()}
function sample(x,y){
 if(getMode()==='real'||getMode()==='phone'){
  if(!ui.connected||!ui.last||ui.last.source!==getMode()||Date.now()-ui.readingAt>1800)throw Error('برای ثبت، حسگر/برد باید فعال و داده جدید موجود باشد');
  if(ui.last.fault||!ui.last.calibrated)throw Error('کالیبراسیون حسگر یا دستگاه ناقص است؛ ثبت متوقف شد');
  return ui.last;
 }
 // The screen uses the user's DEMO target settings, never fabricates a real sensor measurement.
 const s=M.make(scan.n,scan.stepM,'demo',scan.coil);
 M.simulate(s,$('target').value,Number($('depth').value),1);
 const p=s.points[M.index(x,y,s.n)];
 return{signal:p.signal,noise:p.noise,threshold:p.threshold,coil:scan.coil,detected:p.detected,calibrated:true,fault:false};
}
function record(){checkMode();if(getMode()!==scan.source||scan.coil!==(document.querySelector('[data-coil].active')?.dataset.coil||scan.coil)){note('منبع اسکن قبلی متفاوت است؛ پاک‌کردن اسکن را بزن');return}
 const c=currentCell();if(!c){note('تمام نقاط شبکه ثبت شده‌اند');return}
 try{const reading=sample(c.x,c.y);const i=M.index(c.x,c.y,scan.n);ui.undo.push({i,old:scan.points[i]});M.add(scan,c.x,c.y,reading,{source:scan.source});ui.selected=M.next(scan);persist();update();note('نقطه '+(c.y+1)+'،'+(c.x+1)+' ثبت شد');}catch(e){note(e.message)}}
function undo(){const u=ui.undo.pop();if(!u){note('نقطه‌ای برای بازگشت وجود ندارد');return}scan.points[u.i]=u.old;ui.selected={x:u.i%scan.n,y:Math.floor(u.i/scan.n)};persist();update();}
function clear(){initSession();note('شبکه جدید و خالی ایجاد شد')}
function fillDemo(){if(getMode()!=='demo'){note('تولید داده نمایشی فقط در حالت شبیه‌ساز ممکن است');return;}if(scan.source!=='demo'||scan.coil!==(document.querySelector('[data-coil].active')?.dataset.coil||scan.coil))initSession();
 ui.undo=[];M.simulate(scan,$('target').value,Number($('depth').value),1);ui.selected=null;persist();update();note('اسکن شبیه‌سازی‌شده ساخته شد؛ داده واقعی نیست');}
function download(name,mime,content){if(window.PhoneBridge?.saveText){window.PhoneBridge.saveText(name,mime,content);return;}const blob=new Blob([content],{type:mime}),a=document.createElement('a'),u=URL.createObjectURL(blob);a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1300)}
function exportJson(){download('pi-fieldlab-grid-'+scan.n+'x'+scan.n+'.json','application/json;charset=utf-8',JSON.stringify(scan,null,2))}
function exportCsv(){const cols=['x','y','xM','yM','signal','noise','threshold','relative','detected','source','coil','at'];const rows=scan.points.filter(Boolean).map(p=>cols.map(k=>p[k]).join(','));download('pi-fieldlab-grid.csv','text/csv;charset=utf-8','\ufeff'+cols.join(',')+'\n'+rows.join('\n'))}
function savePng(){const c=$(ui.view==='3d'?'scanCanvas3d':'scanCanvas2d');if(window.PhoneBridge?.saveBase64){window.PhoneBridge.saveBase64('pi-fieldlab-'+ui.view+'-'+scan.n+'x'+scan.n+'.png','image/png',c.toDataURL('image/png'));return;}c.toBlob(blob=>{if(!blob)return note('خروجی تصویر ناموفق بود');const a=document.createElement('a'),u=URL.createObjectURL(blob);a.href=u;a.download='pi-fieldlab-'+ui.view+'-'+scan.n+'x'+scan.n+'.png';a.click();setTimeout(()=>URL.revokeObjectURL(u),1300)},'image/png')}
function setView(view){ui.view=view;$('view3d').classList.toggle('active',view==='3d');$('view2d').classList.toggle('active',view==='2d');$('scanCanvas3d').hidden=view!=='3d';$('scanCanvas2d').hidden=view!=='2d';document.querySelector('.scan-overlay').textContent=view==='3d'?'↔ لمس و کشیدن: چرخش مدل':'روی مربع بزن تا نقطه انتخاب شود';render();}
function color(t,alpha=1){t=Math.max(0,Math.min(1,t));const stops=[[39,88,145],[35,179,166],[218,206,86],[232,103,64]];const s=Math.min(2,Math.floor(t*3)),q=t*3-s;const a=stops[s],b=stops[s+1];return 'rgba('+a.map((v,i)=>Math.round(v+(b[i]-v)*q)).join(',')+','+alpha+')'}
function setup(canvas){const box=canvas.getBoundingClientRect(),w=Math.max(230,box.width),h=Math.max(240,box.height),dpr=Math.max(1,Math.min(2,devicePixelRatio||1));const iw=Math.round(w*dpr),ih=Math.round(h*dpr);if(canvas.width!==iw||canvas.height!==ih){canvas.width=iw;canvas.height=ih;}const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);return{ctx,w,h}}
function polygon(ctx,pts,fill,stroke='rgba(176,217,225,.3)',lineWidth=.8){ctx.beginPath();ctx.moveTo(pts[0].x,pts[0].y);for(let j=1;j<pts.length;j++)ctx.lineTo(pts[j].x,pts[j].y);ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lineWidth;ctx.stroke();}}
function render3D(){const{ctx,w,h}=setup($('scanCanvas3d'));const n=scan.n,size=scan.n-1,unit=Math.min(w/(n*1.75),h/(n*1.14))*ui.zoom;
 const cy=Math.cos(ui.yaw),sy=Math.sin(ui.yaw),cp=Math.cos(ui.pitch),sp=Math.sin(ui.pitch);
 function v(x,y,z){x-=(n-1)/2;z-=(n-1)/2;const xx=x*cy-z*sy,zz=x*sy+z*cy;return{x:w/2+xx*unit,y:h*.57+zz*sp*unit-y*cp*unit,order:zz};}
 // Ground floor: every unobserved cell remains pale and unfilled.
 for(let y=0;y<n;y++)for(let x=0;x<n;x++){const s=.46,pts=[v(x-s,0,y-s),v(x+s,0,y-s),v(x+s,0,y+s),v(x-s,0,y+s)];polygon(ctx,pts,'rgba(44,76,94,.16)','rgba(105,156,175,.23)',.65)}
 const p=scan.points.filter(Boolean);const max=Math.max(1,...p.map(a=>a.relative));const cells=[];
 for(const pt of p){const t=Math.min(1,pt.relative/Math.max(1,max)),amp=.035+Math.min(2.45,pt.relative/max*2.45),x=pt.x,y=pt.y,s=.44;
  const bottom=[v(x-s,0,y-s),v(x+s,0,y-s),v(x+s,0,y+s),v(x-s,0,y+s)],top=[v(x-s,amp,y-s),v(x+s,amp,y-s),v(x+s,amp,y+s),v(x-s,amp,y+s)];
  cells.push({pt,t,top,bottom,depth:v(x,0,y).order});
 }
 cells.sort((a,b)=>a.depth-b.depth);
 for(const a of cells){const {top:t,bottom:b}=a;polygon(ctx,[b[2],b[3],t[3],t[2]],color(a.t,.57),'rgba(110,182,197,.16)');polygon(ctx,[b[1],b[2],t[2],t[1]],color(a.t,.66),'rgba(110,182,197,.12)');polygon(ctx,[b[0],b[1],t[1],t[0]],color(a.t,.58),'rgba(110,182,197,.10)');polygon(ctx,t,color(a.t,.97),'rgba(212,247,243,.53)',.8);}
 if(ui.selected){let pt=v(ui.selected.x,.13,ui.selected.y);ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(pt.x,pt.y,6,0,Math.PI*2);ctx.stroke();}
 ctx.font='11px Tahoma, sans-serif';ctx.fillStyle='#96bfcd';ctx.textAlign='center';const ox=v(-.45,0,-.7),ex=v(n-.55,0,-.7),ey=v(-.7,0,n-.55);ctx.fillText('X →',ex.x,ex.y-7);ctx.fillText('Y →',ey.x,ey.y-7);ctx.fillText('ارتفاع = شدت نسبی، نه عمق',w/2,18);
 if(!p.length){ctx.textAlign='center';ctx.fillStyle='#a9ccd3';ctx.font='14px Tahoma, sans-serif';ctx.fillText('برای ایجاد نقشه، نقاط را ثبت کن',w/2,h*.89)}
}
let mapRect;
function render2D(){const {ctx,w,h}=setup($('scanCanvas2d')),n=scan.n,side=Math.min(w-40,h-65),cell=side/n,ox=(w-side)/2,oy=27;
 mapRect={ox,oy,side,cell};const positives=scan.points.filter(Boolean),mx=Math.max(1,...positives.map(a=>a.relative));
 for(let y=0;y<n;y++)for(let x=0;x<n;x++){let p=scan.points[M.index(x,y,n)],t=p?Math.min(1,p.relative/mx):0;ctx.fillStyle=p?color(t):'rgba(48,76,92,.26)';ctx.fillRect(ox+x*cell+1,oy+y*cell+1,cell-2,cell-2);ctx.strokeStyle='rgba(111,166,185,.4)';ctx.lineWidth=.7;ctx.strokeRect(ox+x*cell,oy+y*cell,cell,cell);if(p&&cell>26){ctx.fillStyle='#e6f9f5';ctx.font='10px Arial';ctx.textAlign='center';ctx.fillText(p.relative.toFixed(1),ox+(x+.5)*cell,oy+(y+.59)*cell)}}
 if(ui.selected){const{x,y}=ui.selected;ctx.strokeStyle='#ffffff';ctx.lineWidth=2.7;ctx.strokeRect(ox+x*cell+2,oy+y*cell+2,cell-4,cell-4)}
 ctx.fillStyle='#9cbdcb';ctx.font='11px Tahoma, sans-serif';ctx.textAlign='center';ctx.fillText('ستون‌ها ← X (متر)',w/2,h-9);ctx.save();ctx.translate(11,oy+side/2);ctx.rotate(-Math.PI/2);ctx.fillText('ردیف‌ها ← Y',0,0);ctx.restore();}
function render(){if(!scan)return;if(ui.view==='3d')render3D();else render2D();}
function update(){if(!scan)return;const s=M.summary(scan),c=currentCell(),p=s.peak;$('scanProgress').textContent=s.count+' از '+s.total;$('scanProgressBar').style.width=(100*s.coverage).toFixed(1)+'%';$('scanPosition').textContent=c?'ردیف '+(c.y+1)+'، ستون '+(c.x+1):'اسکن کامل';$('scanSource').textContent='منبع: '+(scan.source==='demo'?'شبیه‌ساز':scan.source==='phone'?'مغناطیس‌سنج گوشی':'برد PI واقعی')+' · '+(scan.coil==='small'?'لوپ کوچک':'لوپ بزرگ');$('scanPoint').disabled=!c;
 const r=$('scanReport');r.innerHTML=s.count?`مساحت شبکه: <b>${s.scanWidthM.toFixed(2)} × ${s.scanWidthM.toFixed(2)} متر</b> | تعداد برداشت: <b>${s.count}</b> | نقاط با پاسخ نسبی ≥ ۱: <b>${s.positiveCount}</b> ${p&&s.positiveCount?`| بیشترین پاسخ: <b>${p.relative.toFixed(1)}</b> در مختصات <b>X=${p.xM.toFixed(2)}m, Y=${p.yM.toFixed(2)}m</b>`:'| پاسخ بالاتر از معیار نمایشی مشاهده نشد'}<br><small>شدت‌ها نسبی‌اند و برآورد عمق واقعی یا شکل جسم محسوب نمی‌شوند.</small>`:'هنوز نقطه‌ای ثبت نشده است.';
 render();}
function onReading(evt){ui.last=evt.detail;ui.readingAt=evt.detail.when;ui.connected=evt.detail.source==='phone'?!!evt.detail.calibrated:evt.detail.connected;ui.source=evt.detail.source;ui.coil=evt.detail.coil;}
function onGridSettings(){if(M.count(scan)){note('تغییر شبکه باعث پاک‌شدن نقشه فعلی می‌شود؛ ابتدا خروجی ذخیره کن');$('gridSize').value=scan.n;$('gridStep').value=scan.stepM;return}initSession();}
$('gridSize').addEventListener('change',onGridSettings);$('gridStep').addEventListener('change',onGridSettings);
$('scanPoint').addEventListener('click',record);$('scanDemoFill').addEventListener('click',fillDemo);$('scanUndo').addEventListener('click',undo);$('scanClear').addEventListener('click',clear);
$('view3d').onclick=()=>setView('3d');$('view2d').onclick=()=>setView('2d');$('scanTop').onclick=()=>{ui.yaw=0;ui.pitch=Math.PI/2-.04;ui.zoom=1;setView('3d')};$('scanResetView').onclick=()=>{ui.yaw=-.63;ui.pitch=.76;ui.zoom=1;setView('3d')};$('scanExportJson').onclick=exportJson;$('scanExportCsv').onclick=exportCsv;
$('scanImport').onclick=()=>$('scanImportFile').click();$('scanImportFile').addEventListener('change',async e=>{if(!e.target.files?.length)return;try{const inp=JSON.parse(await e.target.files[0].text());scan=M.validate(inp);ui.undo=[];ui.selected=M.next(scan);$('gridSize').value=scan.n;$('gridStep').value=scan.stepM;persist();update();note('نقشه از فایل بارگذاری شد')}catch(err){note('فایل نامعتبر: '+err.message)}e.target.value=''});
$('scanImage').onclick=savePng;
document.addEventListener('pi:reading',onReading);document.addEventListener('pi:phone-stopped',()=>{ui.connected=false;ui.last=null;});
$('demoMode').addEventListener('click',()=>setTimeout(checkMode,0));$('realMode').addEventListener('click',()=>setTimeout(checkMode,0));$('phoneMode').addEventListener('click',()=>setTimeout(checkMode,0));document.querySelectorAll('[data-coil]').forEach(b=>b.addEventListener('click',()=>setTimeout(checkMode,0)));
const canvas=$('scanCanvas3d'),heat=$('scanCanvas2d');let drag=null;
canvas.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY};canvas.setPointerCapture(e.pointerId)});
canvas.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;ui.yaw+=dx*.014;ui.pitch=Math.min(1.49,Math.max(.18,ui.pitch+dy*.009));drag={x:e.clientX,y:e.clientY};render();});
canvas.addEventListener('pointerup',()=>drag=null);canvas.addEventListener('pointercancel',()=>drag=null);
canvas.addEventListener('wheel',e=>{e.preventDefault();ui.zoom=Math.min(2.1,Math.max(.45,ui.zoom*(e.deltaY<0?1.1:.9)));render()},{passive:false});
heat.addEventListener('click',e=>{const r=heat.getBoundingClientRect(),px=e.clientX-r.left,py=e.clientY-r.top;if(!mapRect)return;const x=Math.floor((px-mapRect.ox)/mapRect.cell),y=Math.floor((py-mapRect.oy)/mapRect.cell);if(x>=0&&x<scan.n&&y>=0&&y<scan.n){ui.selected={x,y};update()}});
const ro=new ResizeObserver(()=>render());ro.observe($('scanRender'));if(!restore())initSession();else update();setView('3d');
})();

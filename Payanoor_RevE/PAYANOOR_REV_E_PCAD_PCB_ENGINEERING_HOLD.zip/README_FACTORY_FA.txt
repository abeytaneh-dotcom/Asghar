PAYANOOR REV E — 2026-11-16 — THREE TRUE .PCB FILES
FORMAT: P-CAD 2006 ASCII, file signature ACCEL_ASCII (NOT renamed KiCad).
All three P-CAD files successfully reimported into KiCad 10.

1. Payanoor_RevE_MAIN.PCB
   Triangular 104mm base, three original mounting positions (69mm screw pitch),
   20 matching mechanical LED insert slots, integrated XL6019 boost concept,
   ATmega8, 5 MOSFETs, 10 parallel LED-stick interfaces, target VIN 9-36V -> 40V.
   MAIN: 52 components, 160 pads, 765 copper tracks, 86 plated vias,
   739 edge contour elements, 2 polygon pours.
   Native KiCad ERC: no errors (library warnings); DRC 0, open nets 0.
2. Payanoor_RevE_STRIP_6V_6S_90x8.PCB
   Six 6V/1W LEDs in series, one 27R 1W SMD 2512 resistor per strip.
   Ten identical 90x8mm sticks with dual solder tabs at BOTH ends.
   One copper face only, 0 vias, KiCad ERC 0 / DRC 0.
3. Payanoor_RevE_TOP_LID_PAYANOOR.PCB
   50mm circular top lid, ten double-slot solder interfaces, PAYANOOR logo,
   NO inter-stick series bridges. KiCad DRC 0.

FACTORY PROCESS RULES RECORDED:
- Minimum trace width = 0.30 mm.
- Copper trace/pad gap >= 0.30 mm.
- Polygon clearance >= 0.50 mm.
- Plated hole diameter >= 0.50 mm with pad extending >= 0.50 mm
  on both +X/-X/+Y/-Y (1.50mm pad for 0.50mm hole).
- One-sided NON-PLATED hole diameter >= 0.70 mm.
- Factory does NOT perform electrical continuity test: client tests bare
  boards before assembly and reports PCB defects within 48 hours.

IMPORTANT HOLD / NOT APPROVED FOR MANUFACTURE:
- The integrated XL6019E1 5A switch cannot deliver ~60W at VIN=9V:
  input current alone is about 7.8A assuming 85% efficiency, and peak
  switch current is higher. Replacing this boost stage with an
  adequately rated high-current external-MOSFET design is mandatory.
- Automotive load dump / reverse polarity / transient surge protection,
  full-load short protection, thermal validation, output regulation,
  high-current loop / copper-current density remain UNVERIFIED.
- 6V 2835 LED exact vendor land pattern and Vf distribution are
  provisional. 27R/1W value is an engineering starting point only.
- P-CAD conversion was round-trip validated for part/track/via/cutout
  COUNT and named power/ground polygon outlines, but not qualified
  for final fabrication; factory must confirm the specific P-CAD
  ASCII import flavor, fill copper polygons, inspect Gerbers and
  manufacturability before any copper order.
- DO NOT order or assemble this prototype as a finished production board.

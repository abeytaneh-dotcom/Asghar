from pcbkit.schematic import Schematic
s=Schematic("board",title="Payanoor 9A / 7.5V LED Buck Controller",rev="A-PROTOTYPE")
def p(ref,sym,val,block,pins,foot,mpn=""):
    fields={"MPN":mpn} if mpn else {}
    s.part(ref,sym,val,block=block,pins=pins,footprint=foot,fields=fields)
def cap(ref,value,n1,n2,foot="Capacitor_SMD:C_0805_2012Metric",block="Buck Power"):
    p(ref,"Device:C",value,block,{"1":n1,"2":n2},foot)
def resistor(ref,value,n1,n2,block="Feedback"):
    p(ref,"Device:R",value,block,{"1":n1,"2":n2},"Resistor_SMD:R_0805_2012Metric")
p("J1","Connector_Generic:Conn_01x02","9-36V INPUT","Input",{"1":"VIN","2":"GND"},"parts:WirePads_2pin_SMD")
p("U1","parts:XL4016E1","XL4016E1","Buck Power",{"1":"GND","2":"FB","3":"SW","4":"VC","5":"VIN"},"parts:XL4016E1_FormedLead_SMD_PROVISIONAL","XL4016E1")
p("D1","parts:MBRB2060CTG","MBRB2060CTG","Buck Power",{"1":"GND","3":"GND","4":"SW"},"parts:TO-263-2_L10.0-W9.1-P5.08-LS15.2-BR","MBRB2060CTG")
p("L1","Device:L","15uH/12.5A","Buck Power",{"1":"SW","2":"+7V5"},"Inductor_SMD:L_Bourns_SRP1770TA_16.9x16.9mm","SRP1770TA-150M")
for i in (1,2):
    p(f"CIN{i}","Device:C_Polarized","470uF/50V","Input",{"1":"VIN","2":"GND"},"Capacitor_SMD:CP_Elec_16x17.5")
cap("CIN3","100nF/50V","VIN","GND",block="Input")
cap("CVC","1uF/50V","VIN","VC")
for i in (1,2):
    p(f"COUT{i}","Device:C_Polarized","1000uF/16V","Output Filter",{"1":"+7V5","2":"GND"},"Capacitor_SMD:CP_Elec_16x17.5")
cap("COUT3","100nF/50V","+7V5","GND",block="Output Filter")
resistor("RLOW","2k 1%","FB","GND")
resistor("RUP","10k 1%","+7V5","FB")
cap("CFF","33nF/50V","+7V5","FB",block="Feedback")
for i in range(1,11):
    p(f"JLED{i}","Connector_Generic:Conn_01x02",f"LED SEGMENT {i}","10 LED outputs",{"1":"+7V5","2":"GND"},"parts:WirePads_2pin_SMD")
s.flag("VIN","GND","+7V5")
s.note("Buck Power","XL4016 Rev 1.6, 15uH high-current inductor and dual-common-cathode 60V diode.")
s.note("10 LED outputs","Ten 2-pad SMD cable landings: each serves an external 6-LED MCPCB segment, 0.9A.")
if __name__=="__main__": s.write("board.kicad_sch")

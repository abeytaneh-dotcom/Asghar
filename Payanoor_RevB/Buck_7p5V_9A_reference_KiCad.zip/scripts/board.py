import pcbnew
import sys
sys.path.insert(0,"scripts")
from pcbkit.pcb import Pcb
from design import s
b=Pcb("board.kicad_pcb",layers=2)
b.outline(100,100,260,205,radius=2.5)
b.update(s)
placement={
"J1":(109,150,90), "U1":(137,151,0), "D1":(149,170,0),"L1":(164,148,0),
"CIN1":(119,120,0),"CIN2":(119,180,0),"CIN3":(125,155,0),"CVC":(125,160,0),
"COUT1":(185,123,0),"COUT2":(185,177,0),"COUT3":(179,152,0),
"RUP":(169,171,0),"RLOW":(169,177,0),"CFF":(170,165,0)}
for i in range(5): placement[f"JLED{i+1}"]=(193+15*i,110,0)
for i in range(5): placement[f"JLED{i+6}"]=(193+15*i,195,0)
b.place(placement)
b.zone("VIN","F.Cu",points=[(106,152),(131,152),(131,158),(106,158)])
b.zone("GND","B.Cu")
b.zone("GND","F.Cu",points=[(101,102),(175,102),(175,202),(101,202)])
b.zone("+7V5","F.Cu",points=[(176,102),(258,102),(258,201),(176,201)])
b.text("PAYANOOR 7.5V / 9A - PROTOTYPE ONLY",175,202)
b.text("FORMED XL4016 FOOTPRINT UNVERIFIED",139,104)
for z in b.board.Zones():
    if z.GetNetname() == "VIN" and z.GetLayer() == pcbnew.F_Cu:
        z.SetAssignedPriority(2)
b.save()

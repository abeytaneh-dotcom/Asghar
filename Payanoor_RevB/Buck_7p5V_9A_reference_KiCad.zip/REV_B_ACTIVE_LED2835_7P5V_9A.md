# PAYANOOR — REV B ACTIVE SPECIFICATION — 2026-11-16
Status: DESIGN / HOLD for mechanical, thermal, exact LED MPN and functional testing.
## Explicit user revision; supersedes prior 9V rail
The user explicitly selected Digikala https://www.digikala.com/product/dkp-5762834/ (marketed 2835 6V 1W LED 100 pack), and ordered nominal regulated +7.50V output from VIN 9–36V. Each of 60 LEDs has its own independent **10Ω SMD resistor**, minimum nominal **0.5W** 1210 and derating checked at actual enclosure temperature. Thus **9V previous strip-rail target is obsolete**, replaced by +7.5V for REV B. Preserve mechanical/copper/controls protections from existing contract except where explicitly superseded.
## Electrical power budget (NOMINAL IF Vf=6.00V @ 150mA)
One branch: 1.50V/10Ω =150mA; 0.9W LED electrical; 0.225W resistor loss. Six LEDs strip: 0.90A, 6.75W. Ten strips: 9.00A, 67.5W from +7.5V; 54.0W LED bank, 13.5W ballast loss. Input at assumed 85%=79.4W, at VIN=9V ->8.82A average; at 90%=75W and VIN=36V ->2.08A average. These are not measured, and true electrical current depends on LED manufacturer forward-voltage bin, temperature and actual VOUT tolerance.
## New LED source limitation
The Digikala listing itself is inaccessible to automated fetch; mirror reference marketban.com/product/5762834 says color «مهتابی». Previous customer's beacon may require amber. The current vendor exact manufacturer datasheet, pad drawing, LED Vf/If bin and optical color are NOT VERIFIED. Provisional LED pad land pattern only.
## New strip master project and factory checks
https://pcbkit.io/p/ppmsqngwwyhpewflp
90x8mm, six LED2835 6V, six 10R 0.5W 1210, one +7.5 input solder tab at base and one switched GND return tab at lid, SINGLE front copper (0 vias, 0 backside tracks). Default trace min .30mm and clearance min .30mm; +7V5/GND bus .75mm nominal, branch .4mm nominal, Gerber production pending. ERC0, DRC0, disconnected0. Actual manufacturer applies one-copper aluminum MCPCB with conductive heat spreader and electrical insulation.
## 7.5V 9A power prototype
https://pcbkit.io/p/pjsjrkb425s4x5e6x
Existing XL4016E1 buck 7.50V 9A 160x105mm 2-sided design is REFERENCE ONLY: fails client 69mm controller footprint, all-native-SMD (TO-220-5 mechanically formed non-SMD), one-copper restriction and 60V input transient; its historical ground-via overload at 9A remains a STOP. No production release.
## More suitable industrial power IC evaluated (DESIGN OPTION only)
TI LM5116MH/NOPB (100V synchronous buck controller HTSSOP-20 EP, native SMT) and TI LM5146QRGYRQ1 (100V QFN with 0.5mm pitch, may violate strict 0.3mm clearance). LM5116 requires MOSFETs, inductor, current limit network, regulated 7.5V feedback with 1.215V reference, correct compensation, input transient polarity protection and measured current. Actual controlled native-SMD design is NOT YET BUILT or VALIDATED, no source substitutions silently allowed.
## Full beacon hardware still required
Original 10-sided 10x 90x8mm sticks spaced36°, outward mount at base and lid; full control board with ATmega8 SMD, 5 MOSFET channels each pair of strips, positions OFF/flash together/rotate, SMD pot, ISP programming, +5V MCU regulator, original panel dimensions and screw holes; production one-sided copper. Control board and mechanical mating are not verified under 7.5V/9A configuration.
## Manufacturer constraints
Minimum track width and clearance 0.30mm, polygon clearance 0.50mm, 2oz for current paths, insulation and surface thermal capability for AL-MCPCB, all SMD components except agreed external wire terminals, no routing vias for truly one-layer PCB. Final approval needs actual Gerber, DRC+DFM to factory specs, ERC0, netlist comparison0 mismatches, thermal, surge, reversed battery, 9-36V regulation and short-circuit tests and signed first article.


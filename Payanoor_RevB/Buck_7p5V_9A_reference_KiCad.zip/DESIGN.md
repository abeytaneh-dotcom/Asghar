# Payanoor LED Buck driver Rev A — Engineering prototype only
## Goal
9–36 VDC to 7.5V nominal / 9A, 60 independent LED-plus-resistor paths on TEN removable 6-LED aluminum segments. SMD electrical components and a lead-formed XL4016E1.
## Structure
Single controller board: input pads => XL4016 buck => 10 output solder-pad pairs. Ten standalone MCPCB LED segment boards, each with six 6V 150mA LED/resistor branches connected across 7.5V and GND.
## Power budget
Output 67.5W nominal: LEDs 54W, 10-ohm resistors 13.5W. Each segment draws 0.9A, consumes 6.75W.
Input worst estimate at 9V, 85% assumed efficiency = 8.82A, 36V 90% = 2.08A. Verify experimentally.
## Design corrections
- XL4016 original physical package is THT TO220-5. A provisional lead-formed SMD footprint based on TO-263-5 pitch is a landing sketch, NOT approved mechanical component footprint. The tab is SW, never GND.
- MBRB2060CTG is dual common cathode: pads 1 and 3 are anodes to GND, pad 4 is tab/cathode to SW. Library symbol name for pin1 NC corrected locally to A1.
- SRP1770TA-470M 47uH is NOT enough for 9A (Irms 8.7A, Isat1 9.5A). Use 15uH SRP1770TA-150M Irms12.5A, Isat1 23A, DCR<=20.5mOhm.
- Original user-specified 0805 VC 1uF 50V requires effective capacitance DC-bias check; recommend physical 1206 qualified alternative if needed.
- 1x 33nF Cff between OUT and FB, following XLSEMI manufacturer reference.
- Input needs separate overvoltage disconnect and reverse polarity protection in vehicle use. A 36V nominal supply and 40V-absolute-max XL4016 cannot be protected against automotive transients with TVS alone.
- LED currents vary with Vf and VOUT. Test every LED manufacturer's 1W rating at hot temperatures.
## Manufacturing limits
Controller board: 2 layer 2oz FR-4; 110x85mm initial outline, wide copper pours/short connections, thermal SW pad only local, ground copper for diode away from switch loop.
LED module: 90x8mm single-layer aluminum MCPCB with insulated dielectric, 6 LEDs + 6x1210 resistors, total 10 copies; securely thermally couple to aluminum housing. Do NOT route an aluminum MCPCB as standard FR4 plated through-hole.
## Validation still needed
KiCad ERC/DRC, mechanical U1 lead-bend jig and actual landed dimensions, thermal tests at Vin 9V/36V, LED current spread and hot-case current; 50V input capacitor ripple rating, switching-waveform measurements; protection stage selection.
## Sources
XLSEMI Rev1.6 https://www.xlsemi.com/datasheet/XL4016-EN.pdf
Bourns https://bourns.com/docs/product-datasheets/srp1770ta.pdf
onsemi https://www.onsemi.com/pdf/datasheet/mbrb2060ct-d.pdf

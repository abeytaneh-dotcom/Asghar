# 7.5V / 9A XL4016 reference — Payanoor contract adaptation
**NOT A CLIENT RELEASE.** This editable buck study (160×105 mm 2 copper layers) is a source topology only and is not a substitute for the original Payanoor 9V 9–36V client product (69mm controller envelope; one copper layer; 10 LED strips 90×8mm; outward lug orientation; ATmega8 0/1/2 modes; five two-strip MOSFET drivers; 60V load-dump survival). The client 9V constant output is incompatible with this 7.5V buck, and a 9V buck cannot regulate at 9V VIN.
Power reference at 7.5V: 60 x (6V x 0.15A) = 54W LED input, 60x(0.15²x10Ω)=13.5W loss, 67.5W buck output. The input current is about 8.82A at 9V/85% assumed efficiency, before control electronics.
Physical/thermal unresolved: formed-lead TO220-5 XL4016 tab electrically SW, ground high-current via bottlenecks, 2oz copper qualification and exact footprints/LED MPN. Do not release Gerbers as production.
The binding original-client requirements and factory acceptance checklist were added to the 9V power project: https://pcbkit.io/p/pv7dm77aolm2mnrof (CLIENT_CONTRACT_FACTORY_REVIEW_20261116.md).


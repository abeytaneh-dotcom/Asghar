from pcbkit.schematic import Schematic
s=Schematic("board",title="PAYANOOR RevB 10x 7.5V 0.9A LED sticks ATmega8 0/1/2",rev="B-Control-Provisional")
def resistor(ref,v,a,b,block="Gate control"):
 s.part(ref,"Device:R",v,block=block,pins={"1":a,"2":b},footprint="Resistor_SMD:R_0805_2012Metric")
def cap(ref,v,a,b,foot="Capacitor_SMD:C_0805_2012Metric",block="5V logic"):
 s.part(ref,"Device:C",v,block=block,pins={"1":a,"2":b},footprint=foot)
s.part("JPOWER","Connector_Generic:Conn_01x02","7.5V / 9A FROM BUCK",block="Incoming power",pins={"1":"+7V5","2":"GND"},footprint="parts:WirePads_2pin_SMD")
s.part("U5","parts:AMS1117-5.0","AMS1117-5.0",block="5V logic",pins={"1":"GND","2":"+5V","3":"+7V5"},footprint="parts:SOT-223-3_TabPin2",fields={"MPN":"AMS1117-5.0"})
cap("C5IN","10uF 16V","+7V5","GND",foot="Capacitor_SMD:C_1206_3216Metric")
cap("C5OUT","22uF 10V Tantalum","+5V","GND",foot="Capacitor_Tantalum_SMD:CP_EIA-3528-21_Kemet-B")
cap("C5HF","100nF","+5V","GND")
s.part("U1","parts:ATmega8A-A","ATmega8A-AU",block="ATmega8 5-channel control",footprint="parts:TQFP-32_7x7mm_P0.8mm",
 pins={"1":"PWM1","2":"PWM2","3":"GND","4":"+5V","5":"GND","6":"+5V","9":"PWM3","10":"PWM4","11":"PWM5","15":"MOSI","16":"MISO","17":"SCK","18":"+5V","20":"AREF","21":"GND","23":"RATE_ADC","29":"RESET","30":"MODE_FLASH","31":"MODE_ROTATE"})
cap("CAVCC","100nF","+5V","GND")
cap("CVCC","100nF","+5V","GND")
cap("CAREF","100nF","AREF","GND")
resistor("RRESET","10k","+5V","RESET",block="ATmega8 5-channel control")
s.part("P1","parts:Trimming Potentiometer","3314G-1-103E",block="Speed potentiometer",pins={"1":"GND","2":"RATE_ADC","3":"+5V"},footprint="parts:TRIM_BOURNS_3314G-1",fields={"MPN":"3314G-1-103E"})
s.part("JMODE","Connector_Generic:Conn_01x03","OFF / SIMULTANEOUS / ROTATING",block="Remote 3 position switch",pins={"1":"MODE_FLASH","2":"GND","3":"MODE_ROTATE"},footprint="parts:ModePads_3pin_SMD")
resistor("RMODE1","10k","+5V","MODE_FLASH",block="Remote 3 position switch")
resistor("RMODE2","10k","+5V","MODE_ROTATE",block="Remote 3 position switch")
s.part("JISP","Connector_Generic:Conn_02x03_Odd_Even","SMD ISP-6",block="ISP programming",pins={"1":"MISO","2":"+5V","3":"SCK","4":"MOSI","5":"RESET","6":"GND"},footprint="parts:AVR_ISP_SMD_2x3")
for i in range(1,6):
 pwm=f"PWM{i}";gate=f"GATE{i}";load=f"RET{i}"
 s.part(f"Q{i}","parts:AO3400A","AO3400A",block=f"LED pair {i} / 1.8A",pins={"1":gate,"2":"GND","3":load},footprint="parts:SOT-23",fields={"MPN":"AO3400A"})
 resistor(f"RG{i}","47R",pwm,gate,block=f"LED pair {i} / 1.8A")
 resistor(f"RPD{i}","100k",gate,"GND",block=f"LED pair {i} / 1.8A")
for i in range(1,11):
 group=((i-1)//2)+1
 s.part(f"JLED{i}","Connector_Generic:Conn_01x02",f"LED_STRIP_{i}",block="10 LED stick connectors",pins={"1":"+7V5","2":f"RET{group}"},footprint="parts:WirePads_2pin_SMD")
s.flag("+7V5","GND")
s.note("10 LED stick connectors","Each 90×8mm strip is +7.5V to switched return. Adjacent strips share one of 5 MOSFET drain nets.")
s.note("ATmega8 5-channel control","Internal 8MHz clock, 5 outputs PD3-PD7. Enable pull-up after reset; OFF/FLASH/ROTATE modes selected by two active-low inputs. PCB needs firmware.")
if __name__=="__main__":s.write("board.kicad_sch")

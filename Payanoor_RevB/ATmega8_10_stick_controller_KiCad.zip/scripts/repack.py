import pcbnew,random,math,json
from shapely.geometry import box,Polygon
b=pcbnew.LoadBoard('board.kicad_pcb')
poly=Polygon([(150+34.5*math.cos(2*math.pi*i/10),150+34.5*math.sin(2*math.pi*i/10)) for i in range(10)]).buffer(-0.35)
f={x.GetReference():x for x in b.GetFootprints()}
def mm(x):return pcbnew.ToMM(x)
def data(x):
 p=x.GetPosition(); bb=x.GetCourtyard(pcbnew.F_CrtYd).BBox()
 if bb.GetWidth()<10000:bb=x.GetBoundingBox(False,False)
 return (mm(p.x),mm(p.y),mm(bb.GetX())-mm(p.x),mm(bb.GetY())-mm(p.y),mm(bb.GetWidth()),mm(bb.GetHeight()))
g={n:data(x) for n,x in f.items()}
fixed={n for n in f if n.startswith('JLED')};fixed.add('U1')
placed={}
for n in fixed:
 x,y,dx,dy,w,h=g[n]
 placed[n]=box(x+dx-.2,y+dy-.2,x+dx+w+.2,y+dy+h+.2)
 if not poly.contains(placed[n]):print('FIXED EDGE WARN',n)
items=[n for n in f if n not in fixed]
items.sort(key=lambda n:-(g[n][4]*g[n][5]))
out={}
for n in items:
 x,y,dx,dy,w,h=g[n]
 options=[]
 for rr in range(0,44,1):
  for deg in range(0,360,10):
   a=math.radians(deg)
   xx=round(x+rr*math.cos(a),1); yy=round(y+rr*math.sin(a),1)
   if xx==x and yy==y and rr>0:continue
   if not (116<xx<184 and 116<yy<184):continue
   bb=box(xx+dx-.35,yy+dy-.35,xx+dx+w+.35,yy+dy+h+.35)
   if not poly.contains(bb):continue
   if any(bb.intersects(v) for v in placed.values()):continue
   cost=(xx-x)**2+(yy-y)**2
   if rr>0: cost+=.01*rr
   options.append((cost,xx,yy,bb))
  if options and rr>=3:break
 if not options:
  print('UNPLACED',n);continue
 _,xx,yy,bb=min(options,key=lambda a:a[0])
 placed[n]=bb
 out[n]=[xx,yy]
 print(n,'moved',round(xx-x,1),round(yy-y,1))
json.dump(out,open('scripts/placement_generated.json','w'),ensure_ascii=False,indent=1)
print('PLACED',len(placed),'/',len(f),'MOVEABLE',len(out))

import sys,math
import pcbnew
sys.path.insert(0,"scripts")
from pcbkit.pcb import Pcb
from design import s
b=Pcb("board.kicad_pcb",layers=2)
cx,cy=150,150
v=[(cx+34.5*math.cos(2*math.pi*i/10),cy+34.5*math.sin(2*math.pi*i/10)) for i in range(10)]
b.outline(points=v)
b.update(s)
pl={"U1":(150,151,0),"U5":(153,130,0),"JPOWER":(140,130,90),
"C5IN":(162,127,90),"C5OUT":(166,135,90),"C5HF":(158,138,0),
"CVCC":(146,141,0),"CAVCC":(143,154,0),"CAREF":(141,157,0),
"RRESET":(136,147,90),
"P1":(166,154,0),"JMODE":(148,170,0),"JISP":(135,164,0),
"RMODE1":(160,163,0),"RMODE2":(166,163,0)}
for i,deg in enumerate([0,72,144,216,288],1):
 a=math.radians(deg)
 x=cx+16.0*math.cos(a);y=cy+16.0*math.sin(a)
 pl[f"Q{i}"]=(x,y,(deg+90)%360)
 pl[f"RG{i}"]=(cx+11*math.cos(a+.12),cy+11*math.sin(a+.12),deg)
 pl[f"RPD{i}"]=(cx+11*math.cos(a-.12),cy+11*math.sin(a-.12),deg)
for i in range(10):
 a=2*math.pi*i/10+math.pi/10
 pl[f"JLED{i+1}"]=(cx+27.0*math.cos(a),cy+27*math.sin(a),-((i*36)+18)+90)
import json
pl.update({k:(v[0],v[1],pl[k][2]) for k,v in json.load(open("scripts/placement_generated.json")).items()})
b.place(pl)
for fp in b.board.GetFootprints():
 fp.Reference().SetVisible(False)
b.zone("GND","B.Cu")
b.save()

/*
 * PAYANOOR REV B - ATmega8A-AU 5 output channels, 10 LED strips
 * F_CPU=1MHz internal RC default clock assumption; no programmed fuse change.
 * PD3..PD7: active-high MOSFET gates (pairs 1..5).
 * PD0 = MODE_FLASH active-low; PD1 = MODE_ROTATE active-low.
 * PC0 ADC0 = 10k speed trimmer, 0..5V.
 * Each channel's drain switches two 0.9A LED strips.
 * All channels start OFF; conflict mode both low -> OFF.
 * Power-on test only after bench checks for startup glitches/current.
 */
#ifndef F_CPU
#define F_CPU 1000000UL
#endif
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>
#define OUTPUT_MASK 0xF8
volatile uint16_t ms10_tick=0;
ISR(TIMER1_COMPA_vect){ ms10_tick++; }
static uint16_t adc0(void) {
 ADMUX=(1<<REFS0); // AVCC voltage reference, ADC0 PC0
 ADCSRA|=(1<<ADSC);
 while(ADCSRA&(1<<ADSC)){}
 return ADC;
}
static void outputs(uint8_t five_mask) {
 uint8_t output=((uint8_t)(five_mask&0x1F))<<3;
 PORTD=(uint8_t)((PORTD&(~OUTPUT_MASK))|output|_BV(PD0)|_BV(PD1));
}
int main(void) {
 PORTD&=(uint8_t)(~OUTPUT_MASK);
 DDRD|=OUTPUT_MASK;
 DDRD&=(uint8_t)(~(_BV(PD0)|_BV(PD1)));
 PORTD|=_BV(PD0)|_BV(PD1);
 DDRC&=(uint8_t)(~_BV(PC0));
 ADCSRA=(1<<ADEN)|(1<<ADPS1)|(1<<ADPS0); // ADC clk 125kHz at 1MHz
 TCCR1A=0;
 TCCR1B=(1<<WGM12)|(1<<CS11)|(1<<CS10); // 64 prescaler, CTC
 OCR1A=155; // approximately 10ms
 TIMSK|=(1<<OCIE1A);
 sei();
 uint16_t old_tick=0,elapsed=0;
 uint8_t step=0,was_flash=0,old_mode=0;
 outputs(0);
 while(1) {
   uint16_t now;
   cli(); now=ms10_tick; sei();
   if(now==old_tick) continue;
   old_tick=now;
   uint8_t mode;
   uint8_t sw=(uint8_t)(PIND&(_BV(PD0)|_BV(PD1)));
   if(sw==_BV(PD1)) mode=1; // PD0 grounded => flash
   else if(sw==_BV(PD0)) mode=2; // PD1 grounded => rotate
   else mode=0;
   if(mode!=old_mode) {elapsed=0;step=0;was_flash=0;old_mode=mode;outputs(0);}
   if(mode==0) {outputs(0);continue;}
   uint16_t a=adc0();
   uint16_t ticks=(uint16_t)(10+(uint32_t)a*90/1023); // 100..1000ms/phase
   if(mode==1){
     if(!elapsed) {was_flash=(uint8_t)!was_flash;outputs(was_flash?0x1F:0);}
   } else {
     if(!elapsed) {outputs(_BV(step));step++;if(step>=5)step=0;}
   }
   elapsed++;
   if(elapsed>=ticks)elapsed=0;
 }
}

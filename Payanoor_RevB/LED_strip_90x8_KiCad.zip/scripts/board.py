import sys
sys.path.insert(0,"scripts")
from pcbkit.pcb import Pcb
from design import s
b=Pcb("board.kicad_pcb",layers=2)
b.outline(100,100,190,108,radius=.25)
b.update(s)
coords={"JPLUS":(103.0,106.2,0),"JMINUS":(187.0,101.8,0)}
for i in range(1,7):
  center=114+(i-1)*13.4
  coords[f"R{i}"]=(center-2.2,105.2,90)
  coords[f"D{i}"]=(center+2.1,103.1,0)
b.place(coords)
b.zone("+7V5","F.Cu",points=[(101.0,105.95),(189.0,105.95),(189.0,107.65),(101.0,107.65)])
b.zone("GND","F.Cu",points=[(101.0,100.35),(189.0,100.35),(189.0,102.2),(101.0,102.2)])
# Narrow MCPCB is deliberately unlabelled on silkscreen (board ID in fab drawing)
for fp in b.board.GetFootprints():
 fp.Reference().SetVisible(False)
b.save()

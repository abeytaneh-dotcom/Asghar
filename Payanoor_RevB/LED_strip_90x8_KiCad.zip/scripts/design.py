from pcbkit.schematic import Schematic
s=Schematic("board", title="Payanoor 90x8mm SMD LED2835 6V x6 - 10 ohm each", rev="B-Prototype")
s.part("JPLUS","Connector_Generic:Conn_01x01","BASE_+7.5V",block="Supply solder tabs",pins={"1":"+7V5"},footprint="parts:LED_Single_End_Solder_Tab")
s.part("JMINUS","Connector_Generic:Conn_01x01","LID_GND",block="Supply solder tabs",pins={"1":"GND"},footprint="parts:LED_Single_End_Solder_Tab")
for i in range(1,7):
 n=f"LED_A{i}"
 s.part(f"R{i}","Device:R","10R 0.5W SMD1210",block=f"LED current ballast branch {i}",pins={"1":"+7V5","2":n},footprint="Resistor_SMD:R_1210_3225Metric",fields={"Spec":"10ohm 0.5W >= 1% 1210 hot derating verified"})
 s.part(f"D{i}","Device:LED","6V 1W 2835",block=f"LED current ballast branch {i}",pins={"1":"GND","2":n},footprint="parts:LED_2835_6V_1W_PROVISIONAL",fields={"MPN":"Digikala dkp-5762834; no factory datasheet","Warning":"LED polarity and pads require sample check"})
s.flag("+7V5","GND")
s.note("Supply solder tabs","One terminal at the base, other at top lid; six parallel independent 10-ohm + LED paths; 0.9A nominal per stick.")
if __name__=="__main__":s.write("board.kicad_sch")

# PAYANOOR Rev D six-series 3V LED stick — 90x8 mm
KiCad main board 90x8mm single active F.Cu, 0 vias, 0 B.Cu traces. Other KiCad layer is **EDA template only**, not a manufacturing instruction for a two-copper-layer LED MCPCB.
Six nominal 3V/1W 2835 LEDs D1–D6 connected **in series**, one R1=5.1ohm 1210 >=0.5W in series per stick, input ST_IN, output ST_OUT.
At both physical ends, two electrically isolated 2.4x5mm solder tongues, one IN and one OUT, fit customer pre-existing 2-slot bottom base and 2-slot top cap. The tabs are mechanically supported from both boards and thermally bonded to a metal enclosure; verify with first-article assembly.
**Ten identical sticks:** make 10 copies. Pair two sticks in series using the dedicated top-lid Rev D bridge network, five pairs in parallel across +38V and five 100V MOSFET drains. Source board: https://pcbkit.io/p/py3od2rdl6rpaftuc
Nominal at 38V, Vf=3V, R=5.1 x2 per pair: I=(38−36)/10.2=0.196A, P each LED=0.588W, resistor=0.196W. LED lot variations around 2.8V yield overcurrent; exact LED manufacturer model, color, polarity pad land and hot Vf tolerance not verified.
Prototype-only LED footprint, no assurance real SMD 2835 solder pads match seller. Aluminum MCPCB insulator breakdown, dielectric conductivity, thermal interface and temperature tests required; assembly and automotive surge NOT qualified.

import pcbnew,sys
sys.path.insert(0,"scripts")
from pcbkit.pcb import Pcb
from design import s
b=Pcb("board.kicad_pcb",layers=2)
b.outline(points=[(100,100.7),(105,100.7),(105,100),(185,100),(185,100.7),
(190,100.7),(190,103.1),(185,103.1),(185,104.9),(190,104.9),(190,107.3),
(185,107.3),(185,108),(105,108),(105,107.3),(100,107.3),(100,104.9),
(105,104.9),(105,103.1),(100,103.1)])
b.update(s)
d={"JBASE":(102.5,104,0),"JLID":(187.5,104,0),"R1":(111.5,104,0)}
for i,x in enumerate([124,134.5,145,155.5,166,176.5],1): d[f"D{i}"]=(x,104,90)
b.place(d)
for fp in b.board.GetFootprints():fp.Reference().SetVisible(False)
# B.Cu keepout: no backside routing or vias on aluminum MCPCB
z=pcbnew.ZONE(b.board)
z.SetIsRuleArea(True)
z.SetDoNotAllowTracks(True)
z.SetDoNotAllowVias(True)
z.SetLayer(pcbnew.B_Cu)
poly=z.Outline();poly.NewOutline()
for x,y in [(99,99),(191,99),(191,109),(99,109)]:
 poly.Append(pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(y)))
b.board.Add(z)
b.save()

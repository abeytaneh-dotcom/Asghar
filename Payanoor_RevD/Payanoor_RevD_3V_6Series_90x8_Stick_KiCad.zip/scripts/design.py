from pcbkit.schematic import Schematic
s=Schematic("board",title="PAYANOOR 90x8mm 6x 3V 1W SMD LEDs SERIES + one 5R1",rev="D-3V-6S-Engineering-HOLD")
for ref in ("JBASE","JLID"):
 s.part(ref,"Connector_Generic:Conn_01x02",ref+" DUAL-END SOLDER LUGS",block="Matching 2.4x5mm lugs",pins={"1":"ST_IN","2":"ST_OUT"},footprint="parts:DualTongue_2Pad_8mm")
s.part("R1","Device:R","5.1ohm 1pct 0.5W 1210",block="Six LED series string",pins={"1":"ST_IN","2":"LED_A1"},footprint="Resistor_SMD:R_1210_3225Metric")
for i in range(1,7):
 n_anode=f"LED_A{i}"
 n_cathode=f"LED_A{i+1}" if i<6 else "ST_OUT"
 s.part(f"D{i}","Device:LED","3V 1W SMD 2835 PROVISIONAL",block="Six LED series string",pins={"2":n_anode,"1":n_cathode},footprint="parts:LED_2835_3V_1W_PROVISIONAL")
s.note("Six LED series string","One 90x8mm stick: IN -> 5R1 -> six 3V LEDs series -> OUT; nominal 18V LED string, pair TWO sticks in series across 38V.")
s.note("Matching 2.4x5mm lugs","Both ends provide two distinct solder tongues; same IN and OUT nets run the length of the stick. 10 sticks: 60 LEDs total.")
if __name__=="__main__":s.write("board.kicad_sch")

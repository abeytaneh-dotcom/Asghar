# PAYANOOR Rev D 50mm lid with five series pair bridges
Circular PCB with 10 radial 8mm strip interfaces (two real slots at each mounting position = 20 Edge.Cuts channels). The lid face carries customer PAYANOOR and '60 LED / REV D 38V' in silk.
Each stick is mechanically soldered at both isolated top tabs. The following FIVE connections are routed on F.Cu in copper and **only these**:
M1 pin2 == M2 pin1; M3 pin2 == M4 pin1; M5 pin2 == M6 pin1; M7 pin2 == M8 pin1; M9 pin2 == M10 pin1.
Other ten top pads are physically isolated. Main base PCB MUST NOT replicate these bridges.
Radius of all ten positions from lid center (125,175) is exactly 20mm, indexed at angles 90,54,18,-18,-54,-90,-126,-162,162,126 degrees; matches main triangle center (152,164.5).
KiCad DRC zero; five routed traces, 0 vias. High-current 0.196A nominal each but 38V open voltage; final solder and electric insulation and vibration must be verified. Factory must check if 20 cutouts at 50mm circumference satisfy slot spacing, PCB thickness and router tool.

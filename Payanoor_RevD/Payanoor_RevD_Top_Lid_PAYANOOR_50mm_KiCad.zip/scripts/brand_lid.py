import pcbnew
b=pcbnew.LoadBoard("board.kicad_pcb")
for t in b.GetDrawings():
 if isinstance(t,pcbnew.PCB_TEXT) and t.GetText() in ("PAYANOOR","60 LED  /  REV C","payanoor"):
  b.Remove(t)
def add(text,x,y,size=2.0,layer=pcbnew.F_SilkS):
 t=pcbnew.PCB_TEXT(b)
 t.SetText(text);t.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x),pcbnew.FromMM(y)))
 t.SetLayer(layer)
 t.SetTextSize(pcbnew.VECTOR2I(pcbnew.FromMM(size),pcbnew.FromMM(size)))
 t.SetTextThickness(pcbnew.FromMM(0.25 if size>=2 else 0.15))
 t.SetHorizJustify(pcbnew.GR_TEXT_H_ALIGN_CENTER)
 t.SetVertJustify(pcbnew.GR_TEXT_V_ALIGN_CENTER)
 b.Add(t)
add("PAYANOOR",125,173.0,2.75)
add("60 LED  /  REV C",125,179.0,1.1)
pcbnew.SaveBoard("board.kicad_pcb",b)

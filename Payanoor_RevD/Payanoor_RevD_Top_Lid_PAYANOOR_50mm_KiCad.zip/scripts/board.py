from pcbkit.pcb import Pcb
from design import s
b=Pcb("board.kicad_pcb",layers=2)
b.update(s)
b.save()

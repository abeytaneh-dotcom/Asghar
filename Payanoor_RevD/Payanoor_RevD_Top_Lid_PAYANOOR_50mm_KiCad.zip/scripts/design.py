from pcbkit.schematic import Schematic
s=Schematic("board",title="PAYANOOR Top lid 50mm | bridge 5 pairs of 6-series 3V LED sticks",rev="D-38V-2x6S")
for pair in range(1,6):
 odd=2*pair-1;even=2*pair
 s.part(f"M{odd}","Connector_Generic:Conn_01x02",f"TOP OF STICK {odd}",block=f"Bridge pair {pair}",pins={"1":f"TOP_A{pair}_POS_NO_WIRE","2":f"SERIES_MID{pair}"},footprint="pcbkit:Lid_Dual_Solder_Annuli_For_FR4_Tabs")
 s.part(f"M{even}","Connector_Generic:Conn_01x02",f"TOP OF STICK {even}",block=f"Bridge pair {pair}",pins={"1":f"SERIES_MID{pair}","2":f"TOP_B{pair}_NEG_NO_WIRE"},footprint="pcbkit:Lid_Dual_Solder_Annuli_For_FR4_Tabs")
s.note("Bridge pair 1","Odd OUT and even IN joined by LID copper ONLY, base must leave complementary 10 tabs isolated.")
if __name__=="__main__":s.write("board.kicad_sch")

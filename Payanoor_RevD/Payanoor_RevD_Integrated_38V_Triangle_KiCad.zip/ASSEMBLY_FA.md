# Rev D mating set
- Main integrated base: https://pcbkit.io/p/pzt465ckuc2zkwsgb
- 90x8mm 6-series LED strip x10: https://pcbkit.io/p/py3od2rdl6rpaftuc
- Branded top lid 50mm 5x bridge: https://pcbkit.io/p/pndpwz6gz3h2lvs64
- Lid and base 10 stick centers both R20mm at angles 90,54,18,-18,-54,-90,-126,-162,162,126 degrees in that order; same 36° increments.
- The struts/LED sticks must physically mate with two 2.4mm solder tongues per end; solder strain and mechanical vibration tests required.
- Wiring base: JLED1 PIN1=+38V, JLED2 PIN2=RET1; JLED3 PIN1=+38V, JLED4 PIN2=RET2; ...; odd PIN2 and even PIN1 must NOT be connected on base.
- Lid: M1 pin2 joins M2 pin1 at MID1; M3 pin2 joins M4 pin1 at MID2; M5 pin2 joins M6 pin1 at MID3; M7 pin2 joins M8 pin1 at MID4; M9 pin2 joins M10 pin1 at MID5. All other lid metal pads not wired.
- AVR flash/rotate 1MHz internal RC firmware file firmware/payanoor_REV_D_38V_ATMEGA8A_1MHz.hex compiled; no physical test.

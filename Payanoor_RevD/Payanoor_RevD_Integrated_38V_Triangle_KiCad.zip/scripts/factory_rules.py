import json
p='board.kicad_pro';x=json.load(open(p))
rules=x['board']['design_settings']['rules']
rules.update(min_track_width=.3,min_clearance=.3,min_copper_edge_clearance=.5,min_via_diameter=1.5,min_via_annular_width=.5,min_through_hole_diameter=.5,min_hole_to_hole=.5)
nets=x['net_settings'];base=nets['classes'][0]
base.update(track_width=.3,clearance=.3,via_diameter=1.5,via_drill=.5)
nets['classes']=nets['classes'][:1]
for n,w in [('POWER_5A',2.0),('GROUND_RETURN',1.0),('SW_NODE',2.0)]:
 t=base.copy();t.update(name=n,priority=len(nets['classes']),track_width=w,clearance=.3)
 nets['classes'].append(t)
nets['netclass_patterns']=[
 {"pattern":"VIN","netclass":"POWER_5A"},
 {"pattern":"+38V","netclass":"POWER_5A"},
 {"pattern":"GND","netclass":"GROUND_RETURN"},
 {"pattern":"SW","netclass":"SW_NODE"}]
open(p,'w').write(json.dumps(x,indent=2))

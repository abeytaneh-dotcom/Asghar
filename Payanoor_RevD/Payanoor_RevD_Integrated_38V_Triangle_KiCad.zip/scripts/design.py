from pcbkit.schematic import Schematic
s=Schematic("board",title="PAYANOOR REV D: 9-36V -> 38V 1A XL6019+ATmega8 on ONE triangular PCB",rev="D-38V-ENGINEERING-HOLD")
def part(ref,sym,val,block,pins,foot,fields=None):
 s.part(ref,sym,val,block=block,pins=pins,footprint=foot,fields=fields or {})
def r(ref,value,a,b,block="Control"):
 part(ref,"Device:R",value,block,{"1":a,"2":b},"Resistor_SMD:R_0805_2012Metric")
def c(ref,value,a,b,block="Control",foot="Capacitor_SMD:C_0805_2012Metric"):
 part(ref,"Device:C",value,block,{"1":a,"2":b},foot)
def cp(ref,value,a,b,block,foot):
 part(ref,"Device:C_Polarized",value,block,{"1":a,"2":b},foot)
part("JIN","Connector_Generic:Conn_01x02","BATTERY 9-36V","Input",{"1":"VIN","2":"GND"},"parts:WirePads_2pin_SMD")
part("U2","parts:XL6019E1","XL6019E1","38V BOOST",{"1":"GND","2":"EN","3":"SW","4":"VIN","5":"FB","6":"SW"},"parts:TO-263-5_TabPin6",{"MPN":"XL6019E1","WARNING":"5A switch cannot guarantee 38W from 9V, engineering HOLD"})
part("L1","Device:L","47uH 8A ABC AGA1265470MTB","38V BOOST",{"1":"VIN","2":"SW"},"parts:IND-SMD_L13.5-W12.6_SRYH")
part("D1","Device:D_Schottky","SS56 5A 60V SMC","38V BOOST",{"1":"+38V","2":"SW"},"Diode_SMD:D_SMC",{"MPN":"SS56","WARNING":"60V VRRM and 5A switch insufficient surge/current margin without validation"})
cp("CIN1","470uF 50V Nichicon UCM1H471MNJ1MS","VIN","GND","38V BOOST","parts:CP_470uF50V_12p5_PROVISIONAL")
c("CIN2","1uF 50V X7R","VIN","GND",block="38V BOOST")
cp("COUT1","220uF 63V","+38V","GND","38V BOOST","Capacitor_SMD:CP_Elec_10x14.3")
cp("COUT2","220uF 63V","+38V","GND","38V BOOST","Capacitor_SMD:CP_Elec_10x14.3")
c("COUT3","100nF 100V","+38V","GND",block="38V BOOST",foot="Capacitor_SMD:C_1206_3216Metric")
r("RFBLOW","1k 1%","FB","GND","38V BOOST")
r("RFB27K","27k 1%","+38V","FB_UP","38V BOOST")
r("RFB2K4","2.4k 1%","FB_UP","FB","38V BOOST")
r("REN","10k","VIN","EN","38V BOOST")
# +5V AVRs: independent 60V maximum VIN high-voltage 5V fixed LDO
part("U5","parts:TPS7A1601ADGNR","TPS7A1650DGNR 5V","5V AVR regulator",{"1":"+5V","4":"GND","5":"VIN","7":"TDELAY","8":"VIN","9":"GND"},"parts:MSOP-8_L3.0-W3.0-P0.65-LS5.0-BL-EP",{"MPN":"TPS7A1650DGNR","PIN2":"DNC fixed output, leave floating"})
c("C5IN","1uF 50V","VIN","GND",block="5V AVR regulator")
c("C5OUT","10uF 10V","+5V","GND",block="5V AVR regulator",foot="Capacitor_SMD:C_1206_3216Metric")
c("C5DELAY","10nF 50V","TDELAY","GND",block="5V AVR regulator")
# Control AVR: mechanical rev C pin assignments, firmware compatibility
part("U1","parts:ATmega8A-A","ATmega8A-AU","ATmega8 Flasher",{"1":"PWM1","2":"PWM2","3":"GND","4":"+5V","5":"GND","6":"+5V","9":"PWM3","10":"PWM4","11":"PWM5","12":"MODE_FLASH","13":"MODE_ROTATE","15":"MOSI","16":"MISO","17":"SCK","18":"+5V","20":"AREF","21":"GND","23":"RATE_ADC","29":"RESET"},"parts:TQFP-32_7x7mm_P0.8mm")
c("CVCC","100nF","+5V","GND")
c("CAVCC","100nF","+5V","GND")
c("CAREF","100nF","AREF","GND")
r("RRESET","10k","+5V","RESET")
part("P1","parts:Trimming Potentiometer","10k pot","Speed",{"1":"GND","2":"RATE_ADC","3":"+5V"},"parts:TRIM_BOURNS_3314G-1")
part("JMODE","Connector_Generic:Conn_01x03","OFF FLASH ROTATE","Control switches",{"1":"MODE_FLASH","2":"GND","3":"MODE_ROTATE"},"parts:ModePads_3pin_SMD")
r("RMODE1","10k","+5V","MODE_FLASH")
r("RMODE2","10k","+5V","MODE_ROTATE")
part("JISP","Connector_Generic:Conn_02x03_Odd_Even","AVR ISP 6P","Programming",{"1":"MISO","2":"+5V","3":"SCK","4":"MOSI","5":"RESET","6":"GND"},"parts:AVR_ISP_SMD_2x3")
for i in range(1,6):
 g=f"GATE{i}";p=f"PWM{i}";ret=f"RET{i}"
 part(f"Q{i}","parts:Q_NMOS_1G_2S_3D","AO3442 100V 1A","Five LED pair switches",{"1":g,"2":"GND","3":ret},"parts:SOT-23",{"MPN":"AO3442"})
 r(f"RG{i}","47R",p,g,"Five LED pair switches")
 r(f"RPD{i}","100k",g,"GND","Five LED pair switches")
# Physical series-pair connections: odd sticks receive +38 at BASE, even sticks return to Qdrain at BASE.
# Opposite ends are ISOLATED at base and must bridge the two sticks ONLY on the TOP LID.
for i in range(1,11):
 pair=(i+1)//2
 if i%2: pins={"1":"+38V","2":f"MID_A{pair}_BASE_FLOAT"}
 else:pins={"1":f"MID_B{pair}_BASE_FLOAT","2":f"RET{pair}"}
 part(f"JLED{i}","Connector_Generic:Conn_01x02",f"STICK{i} 3V 6SER +5R1","Ten removable LED sticks",pins,"parts:LED_8mm_VERTICAL_2PAD")
s.flag("VIN","GND")
s.note("38V BOOST","XL6019E1 actual FB=pin5, EN=pin2, SW=pin3 and TAB pin6. Ipk >5A at 9V 38W. DO NOT PRODUCTION RELEASE.")
s.note("Ten removable LED sticks","Pairs (1,2), (3,4), (5,6), (7,8), (9,10) are SERIES only through the matching LID BRIDGE. Never short MID_A and MID_B on BASE board.")
s.note("5V AVR regulator","Regulator pin5 enable must be verified against exact fixed 5V variant pinout and package datasheet before assembly.")
if __name__=="__main__":s.write("board.kicad_sch")

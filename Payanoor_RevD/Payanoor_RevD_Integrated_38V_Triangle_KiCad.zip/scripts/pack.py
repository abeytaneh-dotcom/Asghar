import pcbnew,math,random,json,collections
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
from shapely.prepared import prep
random.seed(26)
def mm(x):return pcbnew.ToMM(x)
def t(p):return (round(mm(p.x),5),round(mm(p.y),5))
src=pcbnew.LoadBoard('../pricc6zpg7q4pnufftum4qxavky/Payanoor-60W-Rev-I-two-layer-controller-engineering.kicad_pcb')
ed=collections.defaultdict(list)
for e in src.GetDrawings():
 if e.GetLayer()!=pcbnew.Edge_Cuts:continue
 a,b=t(e.GetStart()),t(e.GetEnd());ed[a].append(b);ed[b].append(a)
seen=set();holes=[]
for p in ed:
 if p in seen:continue
 path=[p]; seen.add(p); cur=p; last=None
 for _ in range(1600):
  options=[x for x in ed[cur] if x!=last];n=options[0] if options else p
  if n==p:break
  path.append(n);seen.add(n);last,cur=cur,n
 try:
  poly=Polygon(path)
  if len(path)>3 and poly.area>.1:holes.append(poly)
 except:pass
tri=Polygon([(100,200),(204,200),(152,109.933)])
safe=tri.buffer(-.55).difference(unary_union(holes).buffer(.60))
print('cutouts',len(holes),'free_area',round(safe.area), 'triangle area',round(tri.area))
b=pcbnew.LoadBoard('board.kicad_pcb')
fps={f.GetReference():f for f in b.GetFootprints()}
side={n:('back' if n in ['JIN','U2','D1','L1','CIN1','CIN2','COUT1','COUT2','COUT3','RFBLOW','RFB27K','RFB2K4','REN'] else 'front') for n in fps}
side['CIN1']='back'
loc={n:(mm(f.GetPosition().x),mm(f.GetPosition().y)) for n,f in fps.items()}
bounds={}
for n,f in fps.items():
 bb=f.GetCourtyard(pcbnew.B_CrtYd if side[n]=='back' else pcbnew.F_CrtYd).BBox()
 if mm(bb.GetWidth())<.1:bb=f.GetBoundingBox(False,False)
 cx,cy=loc[n]
 bounds[n]=(mm(bb.GetX())-cx,mm(bb.GetY())-cy,mm(bb.GetWidth()),mm(bb.GetHeight()))
 if bounds[n][2]>22:print('BIG',n,bounds[n])
occ={'front':[],'back':[]}
out={}
def rect(n,x,y,pad=.38):
 dx,dy,w,h=bounds[n]
 return box(x+dx-pad,y+dy-pad,x+dx+w+pad,y+dy+h+pad)
for n in fps:
 if n.startswith('JLED'):
  cx,cy=loc[n];occ['front'].append((n,rect(n,cx,cy,.3)));out[n]=[round(cx,3),round(cy,3),round(fps[n].GetOrientationDegrees(),3)]
# Anchor MCU centrally
for n in ['U1']:
 cx,cy=loc[n];sh=rect(n,cx,cy,.36)
 occ[side[n]].append((n,sh));out[n]=[cx,cy,0]
items=[n for n in fps if n not in out]
items.sort(key=lambda n: (0 if n=='L1' else 1, -(bounds[n][2]*bounds[n][3])))
fail=[]
dirs=[math.radians(v) for v in range(0,360,15)]
for n in items:
 x0,y0=loc[n];target=(x0,y0)
 candidate=None
 # staged rings around preference point
 for radius in [0]+list(range(1,86)):
  pairs=[(x0,y0)] if not radius else [(x0+radius*math.cos(a),y0+radius*math.sin(a)) for a in dirs]
  random.shuffle(pairs)
  for x,y in pairs:
   shp=rect(n,x,y)
   if not safe.covers(shp):continue
   if any(shp.intersects(k) for other,k in occ[side[n]]):continue
   candidate=(x,y,shp);break
  if candidate:break
 if candidate is None:
  fail.append(n);continue
 x,y,shp=candidate;out[n]=[round(x,3),round(y,3),round(fps[n].GetOrientationDegrees(),2),side[n]]
 occ[side[n]].append((n,shp))
 print(n,side[n],'at',round(x,1),round(y,1),'from',target,'wh',tuple(round(v,1) for v in bounds[n][2:]))
print('packed',len(out),'/',len(fps),'FAILED',fail)
json.dump(out,open('scripts/placement.json','w'),indent=2)

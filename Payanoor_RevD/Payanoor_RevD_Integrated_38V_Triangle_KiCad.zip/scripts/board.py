import sys,json,math,pcbnew
from pathlib import Path
sys.path.insert(0,"scripts")
from pcbkit.pcb import Pcb
from design import s
b=Pcb("board.kicad_pcb",layers=2)
b.outline(points=[(100.0,200.0),(204.0,200.0),(152.0,109.933)])
b.update(s)
ref=pcbnew.LoadBoard("../pricc6zpg7q4pnufftum4qxavky/Payanoor-60W-Rev-I-two-layer-controller-engineering.kicad_pcb")
pl={}
for src in ref.GetFootprints():
 n=src.GetReference()
 if n.startswith("J_LED"):
  n="JLED"+n[5:]
  p=src.GetPosition()
  pl[n]=(pcbnew.ToMM(p.x),pcbnew.ToMM(p.y),src.GetOrientationDegrees())
F={"U1":(152,164.5,0),"U5":(164,171,0),"P1":(148,187,0),
"JMODE":(156,193,0),"JISP":(135,188,0),
"C5IN":(173,173,0),"C5OUT":(175,178,0),"C5DELAY":(172,169,0),
"CVCC":(143,160,0),"CAVCC":(141,163,0),"CAREF":(142,167,0),
"RRESET":(140,158,0),"RMODE1":(163,183,0),"RMODE2":(168,183,0)}
pl.update(F)
for i,a in enumerate([0,72,144,216,288],1):
 t=math.radians(a)
 x=152+11*math.cos(t);y=164.5+11*math.sin(t)
 pl[f"Q{i}"]=(x,y,0)
 pl[f"RG{i}"]=(x+2,y+3,0)
 pl[f"RPD{i}"]=(x+4,y+3,0)
B={"JIN":(152,195,90),"U2":(152,150,0),"D1":(164,151,0),
"L1":(152,171,0),
"CIN1":(125,180,0),"CIN2":(141,145,0),
"COUT1":(128,155,0),"COUT2":(173,155,0),
"COUT3":(165,175,0),"RFBLOW":(164,182,0),"RFB27K":(168,182,0),
"RFB2K4":(172,182,0),"REN":(140,151,0)}
for k,v in B.items():pl[k]=(v[0],v[1],v[2],"back")
p=Path("scripts/placement.json")
if p.exists():
 extra=json.loads(p.read_text())
 for k,v in extra.items():
  if k in pl:pl[k]=(v[0],v[1],v[2],v[3]) if len(v)==4 else tuple(v)
b.place(pl)
for fp in b.board.GetFootprints():
 if fp.GetReference() not in ('U1','U5'):continue
 for pad in fp.Pads():
  size=pad.GetSize()
  w=.48 if fp.GetReference()=="U1" else .34
  if size.x>size.y:pad.SetSize(pcbnew.VECTOR2I(size.x,pcbnew.FromMM(w)))
  else:pad.SetSize(pcbnew.VECTOR2I(pcbnew.FromMM(w),size.y))
for f in b.board.GetFootprints():f.Reference().SetVisible(False)
# Original customer's mechanical cutouts + mounting holes in Edge.Cuts
for e in ref.GetDrawings():
 if e.GetLayer()!=pcbnew.Edge_Cuts:continue
 p=e.GetStart();q=e.GetEnd()
 if math.hypot(pcbnew.ToMM(p.x-q.x),pcbnew.ToMM(p.y-q.y))>80:continue
 t=pcbnew.PCB_SHAPE(b.board)
 t.SetShape(pcbnew.SHAPE_T_SEGMENT)
 t.SetStart(p);t.SetEnd(q);t.SetLayer(pcbnew.Edge_Cuts);t.SetWidth(pcbnew.FromMM(.05));b.board.Add(t)
b.zone("GND","B.Cu")
b.zone("+38V","F.Cu",points=[(105,197),(199,197),(152,115)])
for zone in b.board.Zones():zone.SetLocalClearance(pcbnew.FromMM(.65))
b.save()

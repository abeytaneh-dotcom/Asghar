/* Feature-gated comparison UI. Phone magnetometer/NFC never emits metal/type/depth. */
(()=>{'use strict';const $=x=>document.getElementById(x),M=window.PIMetalID;
const key='pi-fieldlab-revF-calibration',refs=(()=>{try{const v=JSON.parse(localStorage.getItem(key)||'[]');return Array.isArray(v)?v.filter(x=>{try{M.validate(x);return true;}catch(_){return false;}}).slice(0,600):[];}catch(_){return[];}})();
let latest=null,source='demo',pendingDemo=null,selectedDemo='iron',lastSpectrumAt=0;
const notify=x=>{const e=$('metalMessage');e.textContent=x;};
function sampleMode(){return $('phoneMode').classList.contains('selected')?'phone':$('realMode').classList.contains('selected')?'real':'demo';}
function resetText(msg){$('metalClass').textContent='نامعلوم';$('metalScore').textContent='—';$('metalDepth').textContent='—';$('metalScores').innerHTML='';notify(msg);}
function rows(classified){$('metalScores').innerHTML=classified.ranked.map(x=>`<div class="metal-bar"><span>${x.label}</span><div><i style="width:${x.score}%"></i></div><strong>${x.score}%</strong></div>`).join('');}
function updateCalCount(){$('metalCalibrationCount').textContent=refs.length+' نمونه ثبت‌شده';}
function useSample(sample,mode){latest=sample;source=mode;let c;
try{const clean=M.validate(sample);const reference=mode==='demo'?M.demoReferences(clean.coil):refs;c=M.classification(clean,reference);}
catch(e){resetText(e.message);return;}
if(!c.ok){resetText(c.reason);return;}
$('metalClass').textContent=c.label;$('metalScore').textContent=(c.ranked[0]?.score??'—')+'٪ شباهت';rows(c);
if(mode==='demo'){$('metalDepth').textContent='—';notify('صرفاً شبیه‌سازی: درصدها امتیاز الگوریتم روی داده ساختگی هستند. فاصله اسلایدر، عمق اندازه‌گیری‌شده نیست.');return;}
const estimated=M.depth(sample,refs,c.metal,$('metalAssumedSize').value);
$('metalDepth').textContent=estimated.ok?`${estimated.minCm} تا ${estimated.maxCm} سانتی‌متر`:'نامعلوم';notify(estimated.ok?`تخمین مشروط به اندازه ${M.SIZES[estimated.assumedSize]}، لوپ و هندسه مشابه نمونه مرجع؛ R²=${estimated.fitR2}. این عدد عمق قطعی نیست.`:`${estimated.reason} ${c.note}`);
}
function dataHandler(e){const v=e.detail;if(!v)return;const mode=v.source;
if(mode==='phone'){latest=null;resetText('مغناطیس‌سنج/NFC گوشی نوع فلز و عمق را اندازه نمی‌گیرد. برای این قابلیت، داده چندپنجره‌ای برد PI لازم است.');return;}
if(mode==='demo'){
 if(v.target==='none'||!v.detected){latest=null;resetText('در شبیه‌سازی هدف قابل‌تشخیص نیست.');return;}
 pendingDemo=M.demoSample(selectedDemo,v.coil,v.depthTestCm||30,Math.round(v.when/1000));useSample(pendingDemo,'demo');return;
}
if(mode==='real'){
 if(!v.spectrum && Date.now()-lastSpectrumAt<3500)return;
 if(!v.spectrum){latest=null;resetText('فریم معمولی PI فقط شدت را دارد. برای تفکیک، پنج پنجره مستقل پاسخ پالسی و نویز لازم است (پروتکل PF v2).');return;}
 lastSpectrumAt=Date.now();useSample(v.spectrum,'real');
}
}
document.addEventListener('pi:reading',dataHandler);
$('metalDemoSelect').addEventListener('change',e=>{selectedDemo=e.target.value;if(sampleMode()==='demo'&&latest&&pendingDemo){useSample(M.demoSample(selectedDemo,pendingDemo.coil,Number($('depth').value),10),'demo');}});
$('metalAssumedSize').addEventListener('change',()=>{if(latest)useSample(latest,source);});
$('metalCalSave').addEventListener('click',()=>{if(source==='demo'||source==='phone'||!latest){notify('نمونه‌های دمو و گوشی نباید به‌عنوان مرجع فلز واقعی ذخیره شوند.');return;}
 try{const entry=M.entry(latest,$('metalReference').value,Number($('metalKnownDepth').value),$('metalAssumedSize').value);refs.push(entry);if(refs.length>600)refs.shift();localStorage.setItem(key,JSON.stringify(refs));updateCalCount();notify('مرجع ثبت شد. برای هر فلز دست‌کم ۳ برداشت و برای تخمین عمق، ۳ فاصله معلوم لازم است.');useSample(latest,source);}catch(e){notify(e.message);}
});
$('metalCalClear').addEventListener('click',()=>{if(!confirm('تمام داده‌های کالیبراسیون ذخیره‌شده در گوشی پاک شوند؟'))return;refs.length=0;localStorage.removeItem(key);latest=null;updateCalCount();resetText('کالیبراسیون‌های قبلی پاک شدند.');});
$('metalCalExport').addEventListener('click',()=>{const content=JSON.stringify({format:'pi-metal-cal-v1',createdAt:new Date().toISOString(),samples:refs},null,2);if(window.PhoneBridge?.saveText)window.PhoneBridge.saveText('pi-metal-references.json','application/json',content);else{const blob=new Blob([content],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='pi-metal-references.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}});
$('metalRawImport').addEventListener('change',async e=>{try{const file=e.target.files[0];if(!file)return;const raw=JSON.parse(await file.text());const obj=raw.spectrum||raw;M.validate(obj);useSample(obj,'import');notify('نمونه فایل بارگذاری شد؛ منشأ آزمایشگاهی آن به‌طور مستقل تأیید نشده است. '+$('metalMessage').textContent);}catch(ex){resetText('فایل سیگنال قابل‌قبول نیست: '+ex.message);}finally{e.target.value='';}});
$('metalRawOpen').onclick=()=>$('metalRawImport').click();
window.PIMetalPanel={onSpectrum:(raw)=>{try{lastSpectrumAt=Date.now();useSample(raw,'real');}catch(e){resetText(e.message)}},onDisconnect:()=>{latest=null;lastSpectrumAt=0;resetText('BLE قطع است؛ هیچ تخمین زنده‌ای معتبر نیست.');}};
updateCalCount();resetText('به حالت دمو برو و یک جسم انتخاب کن؛ برای داده واقعی باید برد چندپنجره‌ای PI متصل باشد.');
})();
